﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sony
{
    namespace NP
    {
        internal static class Compatibility
        {
            // serviceType is an interger value based on the real service type for the current SDK the .prx is built against.
            // If the SDK for the .prx isn't the latest SDK then this 'old' int value needs to be converted back into the correct enum.
            internal static ServiceTypes ConvertServiceToEnum(Int32 serviceType)
            {
                // Apply a conversion from a service type to the new enum, based on  serviceType to the old version
                if (Main.initResult.sceSDKVersion >= 0x05000000)
                {
                    return (ServiceTypes)serviceType;
                }
                else if (Main.initResult.sceSDKVersion >= 0x04500000)
                {
                    return ConvertFrom((ServiceTypes_SDK4_5)serviceType);
                }

                return ServiceTypes.Invalid;
            }

            internal static FunctionTypes ConvertFunctionToEnum(Int32 functionType)
            {
                // Apply a conversion from a service type to the new enum, based on  serviceType to the old version
                if (Main.initResult.sceSDKVersion >= 0x06500000)
                {
                    return (FunctionTypes)functionType;
                }
                else if (Main.initResult.sceSDKVersion >= 0x05000000)
                {
                    return ConvertFrom((FunctionTypes_SDK6_0)functionType);
                }
                else if (Main.initResult.sceSDKVersion >= 0x04500000)
                {
                    return ConvertFrom((FunctionTypes_SDK4_5)functionType);
                }

                return FunctionTypes.Invalid;
            }

            // serviceType is based on the latest SDK. if the .prx isn't built against the latest SDK, then return the old value
            // from a previous enum.
            internal static Int32 ConvertFromEnum(ServiceTypes serviceType)
            {
                if (Main.initResult.sceSDKVersion >= 0x05000000)
                {
                    return (Int32)serviceType;
                }
                else if (Main.initResult.sceSDKVersion >= 0x04500000)
                {
                    return (Int32)ConvertToSDK45(serviceType);
                }

                return (Int32)ServiceTypes.Invalid;
            }

            // functionType is based on the latest SDK. if the .prx isn't built against the latest SDK, then return the old value
            // from a previous enum.
            internal static Int32 ConvertFromEnum(FunctionTypes functionType)
            {
                // Apply a conversion from a service type to the new enum, based on  serviceType to the old version
                if (Main.initResult.sceSDKVersion >= 0x06500000)
                {
                    return (Int32)functionType;
                }
                else if(Main.initResult.sceSDKVersion >= 0x05000000)
                {
                    return (Int32)ConvertToSDK60(functionType);
                }              
                else if (Main.initResult.sceSDKVersion >= 0x04500000)
                {
                    return (Int32)ConvertToSDK45(functionType);
                }

                return (Int32)FunctionTypes.Invalid;
            }

            static ServiceTypes ConvertFrom(ServiceTypes_SDK4_5 oldServiceType)
            {
                try
                {
                    ServiceTypes serviceType = (ServiceTypes)Enum.Parse(typeof(ServiceTypes), oldServiceType.ToString());
                    return serviceType;
                }
                catch (ArgumentException)
                {
                    return ServiceTypes.Invalid;
                }
            }

            static FunctionTypes ConvertFrom(FunctionTypes_SDK4_5 oldFunctionType)
            {
                try
                {
                    FunctionTypes functionType = (FunctionTypes)Enum.Parse(typeof(FunctionTypes), oldFunctionType.ToString());
                    return functionType;
                }
                catch (ArgumentException)
                {
                    return FunctionTypes.Invalid;
                }
            }

            static FunctionTypes ConvertFrom(FunctionTypes_SDK6_0 oldFunctionType)
            {
                try
                {
                    FunctionTypes functionType = (FunctionTypes)Enum.Parse(typeof(FunctionTypes), oldFunctionType.ToString());
                    return functionType;
                }
                catch (ArgumentException)
                {
                    return FunctionTypes.Invalid;
                }
            }

            static ServiceTypes_SDK4_5 ConvertToSDK45(ServiceTypes serviceType)
            {
                try
                {
                    ServiceTypes_SDK4_5 oldServiceType = (ServiceTypes_SDK4_5)Enum.Parse(typeof(ServiceTypes_SDK4_5), serviceType.ToString());
                    return oldServiceType;
                }
                catch (ArgumentException)
                {
                    return ServiceTypes_SDK4_5.Invalid;
                }
            }

            static FunctionTypes_SDK4_5 ConvertToSDK45(FunctionTypes functionType)
            {
                try
                {
                    FunctionTypes_SDK4_5 oldFunctionType = (FunctionTypes_SDK4_5)Enum.Parse(typeof(FunctionTypes_SDK4_5), functionType.ToString());
                    return oldFunctionType;
                }
                catch (ArgumentException)
                {
                    return FunctionTypes_SDK4_5.Invalid;
                }
            }

            static FunctionTypes_SDK6_0 ConvertToSDK60(FunctionTypes functionType)
            {
                try
                {
                    FunctionTypes_SDK6_0 oldFunctionType = (FunctionTypes_SDK6_0)Enum.Parse(typeof(FunctionTypes_SDK6_0), functionType.ToString());
                    return oldFunctionType;
                }
                catch (ArgumentException)
                {
                    return FunctionTypes_SDK6_0.Invalid;
                }
            }
        }

        internal enum ServiceTypes_SDK4_5
        {
            /// <summary>Non-valid service. It should never be returned (check memset() is not being used in a non-POD object, as a request)</summary>
            Invalid = 0,
            /// <summary>Auth service</summary>
            Auth,
            /// <summary>Presence service</summary>
            Presence,
            /// <summary>Ranking service</summary>
            Ranking,
            /// <summary>Trophy service</summary>
            Trophy,
            /// <summary>Network Utils service</summary>
            NetworkUtils,
            /// <summary>Np Utils service</summary>
            NpUtils,
            /// <summary>Wordfilter service</summary>
            WordFilter,
            /// <summary>User Profile service</summary>
            UserProfile,
            /// <summary>Events Client service</summary>
            EventsClient,
            /// <summary>Messaging service</summary>
            Messaging,
            /// <summary>Matching service</summary>
            Matching,
            /// <summary>Commerce service</summary>
            Commerce,
            /// <summary>Challenge service</summary>
            Challenge,
            /// <summary>TUS service</summary>
            Tus,
            /// <summary>TSS service</summary>
            Tss,
            /// <summary>Friend service</summary>
            Friends,
            /// <summary>Session service</summary>
            Session,
            /// <summary>Activity Feed service</summary>
            ActivityFeed,
            /// <summary>Social Media service</summary>
            SocialMedia,
            /// <summary>Shared Media service</summary>
            SharedMedia,
            /// <summary>Core service. Used only when a Core request is performed</summary>
            Core,
            /// <summary>Notification service. Used to notify when something external to the application happened. Not bound to a request</summary>
            Notification,
            /// <summary>Size of this enum</summary>
            Size	
        };

        /// <summary>
        /// Defines the different APIs provided by the NpToolkit2 library.
        /// It is set automatically when a request object is created, and identifies the function it belongs to.
        /// </summary>
        internal enum FunctionTypes_SDK4_5
        {
            /// <summary>Non-valid function. It should never be returned (check memset() is not being used in a non-POD object, as a request)</summary>
            Invalid = 0,

            /// <summary>Not implemented</summary>
            ActivityFeedGetSharedVideos,
            /// <summary>Not implemented</summary>
            ActivityFeedGetPlayedWith,
            /// <summary>Not implemented</summary>
            ActivityFeedPostPlayedWith,
            /// <summary>Not implemented</summary>
            ActivityFeedGetWhoLiked,
            /// <summary>Not implemented</summary>
            ActivityFeedSetLiked,
            /// <summary>Not implemented</summary>
            ActivityFeedGetFeed,
            /// <summary>Not implemented</summary>
            ActivityFeedPostInGameStory,

            /// <summary>Not implemented</summary>
            AuthGetAuthCode,
            /// <summary>Not implemented</summary>	
            AuthGetIdToken,

            /// <summary>Not implemented</summary>
            ChallengeConsumeChallenge,
            /// <summary>Not implemented</summary>
            ChallengeSendChallenge,
            /// <summary>Not implemented</summary>
            ChallengeGetReceivedChallenges,
            /// <summary>Not implemented</summary>
            ChallengeGetChallengeData,
            /// <summary>Not implemented</summary>
            ChallengeGetChallengeThumbnail,

            /// <summary>Not implemented</summary>
            CommerceGetCategories,						//Commerce::getCategories() function
            /// <summary>Not implemented</summary>
            CommerceGetProducts,						//Commerce::getProducts() function
            /// <summary>Not implemented</summary>
            CommerceGetServiceEntitlements,				//Commerce::getServiceEntitlements() function
            /// <summary>Not implemented</summary>
            CommerceConsumeServiceEntitlement,			//Commerce::getConsumeServiceEntitlement() function
            /// <summary>Not implemented</summary>
            CommerceDisplayCategoryBrowseDialog,		//Commerce::displayCategoryBrowseDialog() function
            /// <summary>Not implemented</summary>
            CommerceDisplayProductBrowseDialog,			//Commerce::displayProductsBrowseDialog() function
            /// <summary>Not implemented</summary>
            CommerceDisplayVoucherCodeInputDialog,		//Commerce::displayVoucherCodeInputDialog() function
            /// <summary>Not implemented</summary>
            CommerceDisplayCheckoutDialog,				//Commerce::displayCheckoutDialog() function
            /// <summary>Not implemented</summary>
            CommerceDisplayJoinPlusDialog,				//Commerce::displayJoinPlusDialog() function
            /// <summary>Not implemented</summary>
            CommerceDisplayDownloadListDialog,			//Commerce::displayDownloadListDialog() function
            /// <summary>Not implemented</summary>
            CommerceSetPsStoreIconDisplayState,			//Commerce::setPsStoreIconDisplayState() function

            /// <summary>Not implemented</summary>
            EventsClientGetEvent,						//EventsClient::getEvent() function

            /// <summary>Used by <see cref="Friends.GetFriends"/></summary>
            FriendsGetFriends,							//Friend::getFriends() function
            /// <summary>Used by <see cref="Friends.GetFriendsOfFriends"/></summary>
            FriendsGetFriendsOfFriends,					//Friend::getFriendsOfFriends() function
            /// <summary>Used by <see cref="Friends.GetBlockedUsers"/></summary>
            FriendsGetBlockedUsers,						//Friend::getBlockedUsers() function
            /// <summary>Used by <see cref="Friends.DisplayFriendRequestDialog"/></summary>
            FriendsDisplayFriendRequestDialog,			//Friend::displayFriendRequestDialog() function
            /// <summary>Used by <see cref="Friends.DisplayBlockUserDialog"/></summary>
            FriendsDisplayBlockUserDialog,				//Friend::displayBlockUserDialog() function

            /// <summary>Not implemented</summary>
            MatchingSetInitConfiguration,				//Matching::setInitConfiguration() function
            /// <summary>Not implemented</summary>
            MatchingGetWorlds,							//Matching::getWorlds() function
            /// <summary>Not implemented</summary>
            MatchingCreateRoom,							//Matching::createRoom() function
            /// <summary>Not implemented</summary>
            MatchingLeaveRoom,							//Matching::leaveRoom() function
            /// <summary>Not implemented</summary>
            MatchingSearchRooms,						//Matching::searchRooms() function
            /// <summary>Not implemented</summary>
            MatchingJoinRoom,							//Matching::joinRoom() function
            /// <summary>Not implemented</summary>
            MatchingGetRoomPingTime,					//Matching::getRoomPingTime() function
            /// <summary>Not implemented</summary>
            MatchingKickOutRoomMember,					//Matching::kickOutRoomMember() function
            /// <summary>Not implemented</summary>
            MatchingSendRoomMessage,					//Matching::sendRoomMessage() function
            /// <summary>Not implemented</summary>
            MatchingGetAttributes,						//Matching::getAttributes() function
            /// <summary>Not implemented</summary>
            MatchingSetRoomInfo,						//Matching::setRoomInfo() function
            /// <summary>Not implemented</summary>
            MatchingSendInvitation,						//Matching::sendInvitation() function
            /// <summary>Not implemented</summary>
            MatchingGetData,
            /// <summary>Added In SDK 4.5</summary>
            MatchingSetMembersAsRecentlyMet,

            /// <summary>Not implemented</summary>
            MessagingSendInGameMessage,					//Messaging::sendInGameMessage() function

            /// <summary>Not implemented</summary>
            MessagingSendGameDataMessage,				//Messaging::sendGameDataMessage() function
            /// <summary>Not implemented</summary>
            MessagingDisplayReceivedGameDataMessagesDialog, //Messaging::displayReceivedGameDataMessagesDialog() function
            /// <summary>Not implemented</summary>
            MessagingGetReceivedGameDataMessages,		//Messaging::getReceivedGameDataMessages() function
            /// <summary>Not implemented</summary>
            MessagingConsumeGameDataMessage,			//Messaging::consumeGameDataMessage() function
            /// <summary>Not implemented</summary>
            MessagingGetGameDataMessageThumbnail,		//Messaging:getGameDataMessageThumbnail() function
            /// <summary>Not implemented</summary>
            MessagingGetGameDataMessageAttachment,		//Messaging:getGameDataMessageAttachment() function

            /// <summary>Used by <see cref="NetworkUtils.GetBandwidthInfo"/></summary>
            NetworkUtilsGetBandwidthInfo,				//NetworkUtils::getBandwithInfo() function
            /// <summary>Used by <see cref="NetworkUtils.GetBasicNetworkInfoInfo"/></summary>
            NetworkUtilsGetBasicNetworkInfo,			//NetworkUtils::getBasicNetworkInfo() function
            /// <summary>Used by <see cref="NetworkUtils.GetDetailedNetworkInfo"/></summary>
            NetworkUtilsGetDetailedNetworkInfo,			//NetworkUtils::getDetailedNetworkInfo() function

            /// <summary>Used by <see cref="NpUtils.DisplaySigninDialog"/></summary>
            NpUtilsDisplaySigninDialog,					//NpUtils::displaySigninDialog() function
            /// <summary>Used by <see cref="NpUtils.SetTitleIdForDevelopment"/></summary>
            NpUtilsSetTitleIdForDevelopment,			//NpUtils::setTitleIdForDevelopment() function
            /// <summary>Used by <see cref="NpUtils.CheckAvailablity"/></summary>
            NpUtilsCheckAvailability,					//NpUtils::checkAvailability() function


            /// <summary>Used by <see cref="Presence.SetPresence"/></summary>
            PresenceSetPresence,						//Presence::setPresence() function
            /// <summary>Used by <see cref="Presence.GetPresence"/></summary>
            PresenceGetPresence,						//Presence::getPresence() function
            /// <summary>Used by <see cref="Presence.DeletePresence"/></summary>
            PresenceDeletePresence,						//Presence::deletePresence() function

            /// <summary>Not implemented</summary>
            RankingSetScore,							//Ranking::setScore() function
            /// <summary>Not implemented</summary>
            RankingGetRangeOfRanks,						//Ranking::getRangeOfRanks() function
            /// <summary>Not implemented</summary>
            RankingGetFriendsRanks,						//Ranking::getFriendsRanks() function
            /// <summary>Not implemented</summary>
            RankingGetUsersRanks,						//Ranking::getUsersRanks() function
            /// <summary>Not implemented</summary>
            RankingSetGameData,							//Ranking::setGameData() function
            /// <summary>Not implemented</summary>
            RankingGetGameData,							//Ranking::getGameData() function

            /// <summary>Not implemented</summary>
            SessionSendInvitation,						//Session::sendInvitation() function
            /// <summary>Not implemented</summary>
            SessionDisplayReceivedInvitationsDialog,	//Session::displayReceivedInvitationsDialog() function
            /// <summary>Not implemented</summary>
            SessionGetReceivedInvitations,				//Session::getReceivedInvitations() function
            /// <summary>Not implemented</summary>
            SessionGetInvitationData,					//Session::getInvitationData() function
            /// <summary>Not implemented</summary>
            SessionConsumeInvitation,					//Session::consumeInvitation() function
            /// <summary>Not implemented</summary>
            SessionGetData,								//Session::getData() function
            /// <summary>Not implemented</summary>
            SessionLeave,								//Session::leave() function
            /// <summary>Not implemented</summary>
            SessionUpdate,								//Session::update() function
            /// <summary>Not implemented</summary>
            SessionGetInfo,								//Session::getInfo() function
            /// <summary>Not implemented</summary>
            SessionJoin,								//Session::join() function
            /// <summary>Not implemented</summary>
            SessionSearch,								//Session::search() function
            /// <summary>Not implemented</summary>
            SessionCreate,								//Session::create() function

            /// <summary>Not implemented</summary>
            SocialMediaPostMessageToFacebook,			//SocialMedia::postMessageToFacebook() function

            /// <summary>Not implemented</summary>
            SharedMediaGetScreenshots,					//SharedMedia::getScreenshots() function
            /// <summary>Not implemented</summary>
            SharedMediaGetBroadcasts,					//SharedMedia::getBroadcasts() function
            /// <summary>Not implemented</summary>
            SharedMediaGetVideos,						//SharedMedia::getVideos() function

            /// <summary>Used by <see cref="Trophies.RegisterTrophyPack"/></summary>
            TrophyRegisterTrophyPack,					//Trophy::registerTrophyPack() function
            /// <summary>Used by <see cref="Trophies.UnlockTrophy"/></summary>
            TrophyUnlock,								//Trophy::unlock() function
            /// <summary>Used by <see cref="Trophies.SetScreenshot"/></summary>
            TrophySetScreenshot,						//Trophy::setScreenshot() function
            /// <summary>Used by <see cref="Trophies.GetUnlockedTrophies"/></summary>
            TrophyGetUnlockedTrophies,					//Trophy::getUnlockedTrophies() function
            /// <summary>Used by <see cref="Trophies.DisplayTrophyListDialog"/></summary>
            TrophyDisplayTrophyListDialog,				//Trophy::displayTrophyListDialog() function
            /// <summary>Used by <see cref="Trophies.GetTrophyPackSummary"/></summary>
            TrophyGetTrophyPackSummary,					//Trophy::getTrophyPackSummary() function
            /// <summary>Used by <see cref="Trophies.GetTrophyPackGroup"/></summary>
            TrophyGetTrophyPackGroup,					//Trophy::getTrophyPackGroup() function
            /// <summary>Used by <see cref="Trophies.GetTrophyPackTrophy"/></summary>
            TrophyGetTrophyPackTrophy,					//Trophy::getTrophyPackTrophy() function

            /// <summary>Not implemented</summary>
            TssGetData,									//TSS::getData() function

            /// <summary>Not implemented</summary>
            TusSetVariables,							//TUS::setVariables() function
            /// <summary>Not implemented</summary>
            TusGetVariables,							//TUS::getVariables() function
            /// <summary>Not implemented</summary>
            TusAddToAndGetVariable,						//TUS::addToAndGetVariable() function
            /// <summary>Not implemented</summary>
            TusSetData,									//TUS::setData() function
            /// <summary>Not implemented</summary>
            TusGetData,									//TUS::getData() function
            /// <summary>Not implemented</summary>
            TusDeleteData,								//TUS::deleteData() function

            /// <summary>Used by <see cref="UserProfiles.GetNpProfiles"/></summary>
            UserProfileGetNpProfiles,					//UserProfile::getNpProfiles() function
            /// <summary>Used by <see cref="UserProfiles.GetVerifiedAccountsForTitle"/></summary>
            UserProfileGetVerifiedAccountsForTitle,		//UserProfile::getVerifiedAccountsForTitle() function
            /// <summary>Used by <see cref="UserProfiles.DisplayUserProfileDialog"/></summary>
            UserProfileDisplayUserProfileDialog,		// < <c>UserProfile::displayUserProfileDialog() function
            /// <summary>Used by <see cref="UserProfiles.DisplayGriefReportingDialog"/></summary>
            UserProfileDisplayGriefReportingDialog,		// < <c>UserProfile::displayGriefReportingDialog() function

            /// <summary>Not implemented</summary>
            WordfilterFilterComment,					//Wordfilter::filterComment() function

            /// <summary>Not implemented</summary>
            CoreTerminateService,						//Core::terminateService() function

            //Matching notifications
            /// <summary>Not implemented</summary>
            NotificationRefreshRoom,					//The Response in the <c>CallbackEvent is <c>Response\<Matching::Notification::RefreshRoom\>
            /// <summary>Not implemented</summary>
            NotificationNewRoomMessage,					//The Response in the <c>CallbackEvent is <c>Response\<Matching::Notification::NewRoomMessage\>

            //In game message notifications. // Moved from here in SDK 4.5 to later in the enum.
            //NotificationNewInGameMessage,				//The Response in the <c>CallbackEvent is <c>Response\<Messaging::Notification::NewInGameMessage\>

            //Change on focus notifications
            /// <summary>The Response in the callback is <see cref="Core.EmptyResponse"/></summary>
            NotificationDialogOpened,					//The Response in the <c>CallbackEvent is <c>Response\<Core::Empty\>
            /// <summary>The Response in the callback is <see cref="Core.EmptyResponse"/></summary>
            NotificationDialogClosed,					//The Response in the <c>CallbackEvent is <c>Response\<Core::Empty\>
            /// <summary>The Response in the callback is <see cref="NpUtils.UserStateChangeResponse"/></summary>
            NotificationUserStateChange,				//The Response in the <c>CallbackEvent is <c>Response\<Core::Notification::UserStateChange\>
            /// <summary>The Response in the callback is <see cref="NetworkUtils.NetStateChangeResponse"/></summary>
            NotificationNetStateChange,					//The Response in the <c>CallbackEvent is <c>Response\<Core::Notification::NetStateChange\>

            //Server push notifications
            /// <summary>Not implemented</summary> // Moved here in SDK 4.5
            NotificationNewInGameMessage,				//The Response in the <c>CallbackEvent is <c>Response\<Messaging::Notification::NewInGameMessage\>
            /// <summary>The Response in the callback is <see cref="Friends.FriendListUpdateResponse"/></summary>
            NotificationUpdateFriendsList,				//The Response in the <c>CallbackEvent is <c>Response\<Friend::Notification::UpdateFriendsList\>
            /// <summary>Not implemented</summary>
            NotificationNewInvitation,					//The Response in the <c>CallbackEvent is <c>Response\<Invitation::Notification::NewInvitation\>
            /// <summary>Not implemented</summary>
            NotificationNewGameDataMessage,				//The Response in the <c>CallbackEvent is <c>Response\<Messaging::Notification::NewGameDataMessage\>
            /// <summary>The Response in the callback is <see cref="Presence.PresenceUpdateResponse"/></summary>
            NotificationUpdateFriendPresence,			//The Response in the <c>CallbackEvent is <c>Response\<Friend::Notification::UpdateFriendPresence\>
            /// <summary>The Response in the callback is <see cref="Friends.BlocklistUpdateResponse"/></summary>
            NotificationUpdateBlockedUsersList,			//The Response in the <c>CallbackEvent is <c>Response\<Friend::Notification::UpdateBlockedUsersList\>

            //Abort notifications
            /// <summary>The Response in the callback is <see cref="Core.EmptyResponse"/></summary>
            NotificationAborted,						//The Response in the <c>CallbackEvent is <c>Response\<Core::Empty\>. See <c>Core::abortRequest()

            /// <summary>The number of function types</summary>	
            NumFunctionTypes,

            // Custom notification types. These aren't provided by NpToolkit, but are implemented in such a way as to look like normal response objects coming in from NpToolkit.

            /// <summary></summary>	
            NotificationSessionInvitationEvent,

            /// <summary></summary>	
            NotificationPlayTogetherHostEvent,

            /// <summary></summary>	
            NotificationGameCustomDataEvent,

            /// <summary></summary>	
            NotificationLaunchAppEvent,

            // Custom requests
            /// <summary></summary>	
            NpUtilsCheckPlus,

            /// <summary></summary>	
            NpUtilsGetParentalControlInfo
        };

        /// <summary>
        /// Defines the different APIs provided by the NpToolkit2 library.
        /// It is set automatically when a request object is created, and identifies the function it belongs to.
        /// </summary>
        public enum FunctionTypes_SDK6_0
        {
            /// <summary>Non-valid function. It should never be returned (check memset() is not being used in a non-POD object, as a request)</summary>
            Invalid = 0,

            /// <summary>Not implemented</summary>
            ActivityFeedGetSharedVideos,
            /// <summary>Not implemented</summary>
            ActivityFeedGetPlayedWith,
            /// <summary>Not implemented</summary>
            ActivityFeedPostPlayedWith,
            /// <summary>Not implemented</summary>
            ActivityFeedGetWhoLiked,
            /// <summary>Not implemented</summary>
            ActivityFeedSetLiked,
            /// <summary>Not implemented</summary>
            ActivityFeedGetFeed,
            /// <summary>Not implemented</summary>
            ActivityFeedPostInGameStory,

            /// <summary>Not implemented</summary>
            AuthGetAuthCode,
            /// <summary>Not implemented</summary>	
            AuthGetIdToken,

            /// <summary>Not implemented</summary>
            ChallengeConsumeChallenge,
            /// <summary>Not implemented</summary>
            ChallengeSendChallenge,
            /// <summary>Not implemented</summary>
            ChallengeGetReceivedChallenges,
            /// <summary>Not implemented</summary>
            ChallengeGetChallengeData,
            /// <summary>Not implemented</summary>
            ChallengeGetChallengeThumbnail,

            /// <summary>Not implemented</summary>
            CommerceGetCategories,                      //Commerce::getCategories() function
                                                        /// <summary>Not implemented</summary>
            CommerceGetProducts,                        //Commerce::getProducts() function
                                                        /// <summary>Not implemented</summary>
            CommerceGetServiceEntitlements,             //Commerce::getServiceEntitlements() function
                                                        /// <summary>Not implemented</summary>
            CommerceConsumeServiceEntitlement,          //Commerce::getConsumeServiceEntitlement() function
                                                        /// <summary>Not implemented</summary>
            CommerceDisplayCategoryBrowseDialog,        //Commerce::displayCategoryBrowseDialog() function
                                                        /// <summary>Not implemented</summary>
            CommerceDisplayProductBrowseDialog,         //Commerce::displayProductsBrowseDialog() function
                                                        /// <summary>Not implemented</summary>
            CommerceDisplayVoucherCodeInputDialog,      //Commerce::displayVoucherCodeInputDialog() function
                                                        /// <summary>Not implemented</summary>
            CommerceDisplayCheckoutDialog,              //Commerce::displayCheckoutDialog() function
                                                        /// <summary>Not implemented</summary>
            CommerceDisplayJoinPlusDialog,              //Commerce::displayJoinPlusDialog() function
                                                        /// <summary>Not implemented</summary>
            CommerceDisplayDownloadListDialog,          //Commerce::displayDownloadListDialog() function
                                                        /// <summary>Not implemented</summary>
            CommerceSetPsStoreIconDisplayState,			//Commerce::setPsStoreIconDisplayState() function
            /// <summary>Not implemented</summary>
            CommerceGetContainers,

            /// <summary>Not implemented</summary>
            CoreTerminateService,                       //Core::terminateService()</c> function.

            /// <summary>Not implemented</summary>
            EventsClientGetEvent,                       //EventsClient::getEvent() function

            /// <summary>Used by <see cref="Friends.GetFriends"/></summary>
            FriendsGetFriends,                          //Friend::getFriends() function
                                                        /// <summary>Used by <see cref="Friends.GetFriendsOfFriends"/></summary>
            FriendsGetFriendsOfFriends,                 //Friend::getFriendsOfFriends() function
                                                        /// <summary>Used by <see cref="Friends.GetBlockedUsers"/></summary>
            FriendsGetBlockedUsers,                     //Friend::getBlockedUsers() function
                                                        /// <summary>Used by <see cref="Friends.DisplayFriendRequestDialog"/></summary>
            FriendsDisplayFriendRequestDialog,          //Friend::displayFriendRequestDialog() function
                                                        /// <summary>Used by <see cref="Friends.DisplayBlockUserDialog"/></summary>
            FriendsDisplayBlockUserDialog,              //Friend::displayBlockUserDialog() function

            /// <summary>Not implemented</summary>
            MatchingSetInitConfiguration,               //Matching::setInitConfiguration() function
                                                        /// <summary>Not implemented</summary>
            MatchingGetWorlds,                          //Matching::getWorlds() function
                                                        /// <summary>Not implemented</summary>
            MatchingCreateRoom,                         //Matching::createRoom() function
                                                        /// <summary>Not implemented</summary>
            MatchingLeaveRoom,                          //Matching::leaveRoom() function
                                                        /// <summary>Not implemented</summary>
            MatchingSearchRooms,                        //Matching::searchRooms() function
                                                        /// <summary>Not implemented</summary>
            MatchingJoinRoom,                           //Matching::joinRoom() function
                                                        /// <summary>Not implemented</summary>
            MatchingGetRoomPingTime,                    //Matching::getRoomPingTime() function
                                                        /// <summary>Not implemented</summary>
            MatchingKickOutRoomMember,                  //Matching::kickOutRoomMember() function
                                                        /// <summary>Not implemented</summary>
            MatchingSendRoomMessage,                    //Matching::sendRoomMessage() function
                                                        /// <summary>Not implemented</summary>
            MatchingGetAttributes,                      //Matching::getAttributes() function
                                                        /// <summary>Not implemented</summary>
            MatchingSetRoomInfo,                        //Matching::setRoomInfo() function
                                                        /// <summary>Not implemented</summary>
            MatchingSendInvitation,                     //Matching::sendInvitation() function
                                                        /// <summary>Not implemented</summary>
            MatchingGetData,
            /// <summary>Added In SDK 4.5</summary>
            MatchingSetMembersAsRecentlyMet,

            /// <summary>Not implemented</summary>
            MessagingSendInGameMessage,                 //Messaging::sendInGameMessage() function

            /// <summary>Not implemented</summary>
            MessagingSendGameDataMessage,               //Messaging::sendGameDataMessage() function
                                                        /// <summary>Not implemented</summary>
            MessagingDisplayReceivedGameDataMessagesDialog, //Messaging::displayReceivedGameDataMessagesDialog() function
                                                            /// <summary>Not implemented</summary>
            MessagingGetReceivedGameDataMessages,       //Messaging::getReceivedGameDataMessages() function
                                                        /// <summary>Not implemented</summary>
            MessagingConsumeGameDataMessage,            //Messaging::consumeGameDataMessage() function
                                                        /// <summary>Not implemented</summary>
            MessagingGetGameDataMessageThumbnail,       //Messaging:getGameDataMessageThumbnail() function
                                                        /// <summary>Not implemented</summary>
            MessagingGetGameDataMessageAttachment,      //Messaging:getGameDataMessageAttachment() function

            /// <summary>Used by <see cref="NetworkUtils.GetBandwidthInfo"/></summary>
            NetworkUtilsGetBandwidthInfo,               //NetworkUtils::getBandwithInfo() function
                                                        /// <summary>Used by <see cref="NetworkUtils.GetBasicNetworkInfoInfo"/></summary>
            NetworkUtilsGetBasicNetworkInfo,            //NetworkUtils::getBasicNetworkInfo() function
                                                        /// <summary>Used by <see cref="NetworkUtils.GetDetailedNetworkInfo"/></summary>
            NetworkUtilsGetDetailedNetworkInfo,			//NetworkUtils::getDetailedNetworkInfo() function

            //Matching notifications
            /// <summary>Not implemented</summary>
            NotificationRefreshRoom,					//The Response in the <c>CallbackEvent is <c>Response\<Matching::Notification::RefreshRoom\>
            /// <summary>Not implemented</summary>
            NotificationNewRoomMessage,					//The Response in the <c>CallbackEvent is <c>Response\<Matching::Notification::NewRoomMessage\>

            //Change on focus notifications
            /// <summary>The Response in the callback is <see cref="Core.EmptyResponse"/></summary>
            NotificationDialogOpened,					//The Response in the <c>CallbackEvent is <c>Response\<Core::Empty\>
            /// <summary>The Response in the callback is <see cref="Core.EmptyResponse"/></summary>
            NotificationDialogClosed,					//The Response in the <c>CallbackEvent is <c>Response\<Core::Empty\>
            /// <summary>The Response in the callback is <see cref="NpUtils.UserStateChangeResponse"/></summary>
            NotificationUserStateChange,				//The Response in the <c>CallbackEvent is <c>Response\<Core::Notification::UserStateChange\>
            /// <summary>The Response in the callback is <see cref="NetworkUtils.NetStateChangeResponse"/></summary>
            NotificationNetStateChange,					//The Response in the <c>CallbackEvent is <c>Response\<Core::Notification::NetStateChange\>

            //Server push notifications
            /// <summary>Not implemented</summary> // Moved here in SDK 4.5
            NotificationNewInGameMessage,				//The Response in the <c>CallbackEvent is <c>Response\<Messaging::Notification::NewInGameMessage\>
            /// <summary>The Response in the callback is <see cref="Friends.FriendListUpdateResponse"/></summary>
            NotificationUpdateFriendsList,				//The Response in the <c>CallbackEvent is <c>Response\<Friend::Notification::UpdateFriendsList\>
            /// <summary>Not implemented</summary>
            NotificationNewInvitation,					//The Response in the <c>CallbackEvent is <c>Response\<Invitation::Notification::NewInvitation\>
            /// <summary>Not implemented</summary>
            NotificationNewGameDataMessage,				//The Response in the <c>CallbackEvent is <c>Response\<Messaging::Notification::NewGameDataMessage\>
            /// <summary>The Response in the callback is <see cref="Presence.PresenceUpdateResponse"/></summary>
            NotificationUpdateFriendPresence,			//The Response in the <c>CallbackEvent is <c>Response\<Friend::Notification::UpdateFriendPresence\>
            /// <summary>The Response in the callback is <see cref="Friends.BlocklistUpdateResponse"/></summary>
            NotificationUpdateBlockedUsersList,			//The Response in the <c>CallbackEvent is <c>Response\<Friend::Notification::UpdateBlockedUsersList\>

            //Abort notifications
            /// <summary>The Response in the callback is <see cref="Core.EmptyResponse"/></summary>
            NotificationAborted,                        //The Response in the <c>CallbackEvent is <c>Response\<Core::Empty\>. See <c>Core::abortRequest()

            /// <summary>Used by <see cref="NpUtils.DisplaySigninDialog"/></summary>
            NpUtilsDisplaySigninDialog,                 //NpUtils::displaySigninDialog() function
                                                        /// <summary>Used by <see cref="NpUtils.SetTitleIdForDevelopment"/></summary>
            NpUtilsSetTitleIdForDevelopment,            //NpUtils::setTitleIdForDevelopment() function
                                                        /// <summary>Used by <see cref="NpUtils.CheckAvailablity"/></summary>
            NpUtilsCheckAvailability,					//NpUtils::checkAvailability() function

            /// <summary>Not implemented/></summary>
            NpUtilsCheckPsPlusAccess,						//< <c>NpUtils::checkPsPlusAccess()</c> function.
            /// <summary>Not implemented/></summary>
            NpUtilsGetAccountIdByOnlineId,					//< <c>NpUtils::getAccountIdByOnlineId()</c> function.
            /// <summary>Not implemented/></summary>
            NpUtilsGetOnlineIdByAccountId,                  //< <c>NpUtils::getOnlineIdByAccountId()</c> function.

            /// <summary>Used by <see cref="Presence.SetPresence"/></summary>
            PresenceSetPresence,                        //Presence::setPresence() function
                                                        /// <summary>Used by <see cref="Presence.GetPresence"/></summary>
            PresenceGetPresence,                        //Presence::getPresence() function
                                                        /// <summary>Used by <see cref="Presence.DeletePresence"/></summary>
            PresenceDeletePresence,                     //Presence::deletePresence() function

            /// <summary>Not implemented</summary>
            RankingSetScore,                            //Ranking::setScore() function
                                                        /// <summary>Not implemented</summary>
            RankingGetRangeOfRanks,                     //Ranking::getRangeOfRanks() function
                                                        /// <summary>Not implemented</summary>
            RankingGetFriendsRanks,                     //Ranking::getFriendsRanks() function
                                                        /// <summary>Not implemented</summary>
            RankingGetUsersRanks,                       //Ranking::getUsersRanks() function
                                                        /// <summary>Not implemented</summary>
            RankingSetGameData,                         //Ranking::setGameData() function
                                                        /// <summary>Not implemented</summary>
            RankingGetGameData,                         //Ranking::getGameData() function

            /// <summary>Not implemented</summary>
            SessionSendInvitation,                      //Session::sendInvitation() function
                                                        /// <summary>Not implemented</summary>
            SessionDisplayReceivedInvitationsDialog,    //Session::displayReceivedInvitationsDialog() function
                                                        /// <summary>Not implemented</summary>
            SessionGetReceivedInvitations,              //Session::getReceivedInvitations() function
                                                        /// <summary>Not implemented</summary>
            SessionGetInvitationData,                   //Session::getInvitationData() function
                                                        /// <summary>Not implemented</summary>
            SessionConsumeInvitation,                   //Session::consumeInvitation() function
                                                        /// <summary>Not implemented</summary>
            SessionGetData,                             //Session::getData() function
                                                        /// <summary>Not implemented</summary>
            SessionLeave,                               //Session::leave() function
                                                        /// <summary>Not implemented</summary>
            SessionUpdate,                              //Session::update() function
                                                        /// <summary>Not implemented</summary>
            SessionGetInfo,                             //Session::getInfo() function
                                                        /// <summary>Not implemented</summary>
            SessionJoin,                                //Session::join() function
                                                        /// <summary>Not implemented</summary>
            SessionSearch,                              //Session::search() function
                                                        /// <summary>Not implemented</summary>
            SessionCreate,								//Session::create() function

            /// <summary>Not implemented</summary>
            SharedMediaGetScreenshots,					//SharedMedia::getScreenshots() function
            /// <summary>Not implemented</summary>
            SharedMediaGetBroadcasts,					//SharedMedia::getBroadcasts() function
            /// <summary>Not implemented</summary>
            SharedMediaGetVideos,                       //SharedMedia::getVideos() function

            /// <summary>Not implemented</summary>
            SocialMediaPostMessageToFacebook,			//SocialMedia::postMessageToFacebook() function

            /// <summary>Not implemented</summary>
            TournamentSearchEvents,
            /// <summary>Not implemented</summary>
            TournamentGetEvent,
            /// <summary>Not implemented</summary>
            TournamentGetRegisteredUsers,
            /// <summary>Not implemented</summary>
            TournamentGetRegisteredTeams,
            /// <summary>Not implemented</summary>
            TournamentGetRegisteredRoster,
            /// <summary>Not implemented</summary>
            TournamentGetBracket,
            /// <summary>Not implemented</summary>
            TournamentSendUserMatchReport,
            /// <summary>Not implemented</summary>
            TournamentSendTeamMatchReport,

            /// <summary>Used by <see cref="Trophies.RegisterTrophyPack"/></summary>
            TrophyRegisterTrophyPack,                   //Trophy::registerTrophyPack() function
                                                        /// <summary>Used by <see cref="Trophies.UnlockTrophy"/></summary>
            TrophyUnlock,                               //Trophy::unlock() function
                                                        /// <summary>Used by <see cref="Trophies.SetScreenshot"/></summary>
            TrophySetScreenshot,                        //Trophy::setScreenshot() function
                                                        /// <summary>Used by <see cref="Trophies.GetUnlockedTrophies"/></summary>
            TrophyGetUnlockedTrophies,                  //Trophy::getUnlockedTrophies() function
                                                        /// <summary>Used by <see cref="Trophies.DisplayTrophyListDialog"/></summary>
            TrophyDisplayTrophyListDialog,              //Trophy::displayTrophyListDialog() function
                                                        /// <summary>Used by <see cref="Trophies.GetTrophyPackSummary"/></summary>
            TrophyGetTrophyPackSummary,                 //Trophy::getTrophyPackSummary() function
                                                        /// <summary>Used by <see cref="Trophies.GetTrophyPackGroup"/></summary>
            TrophyGetTrophyPackGroup,                   //Trophy::getTrophyPackGroup() function
                                                        /// <summary>Used by <see cref="Trophies.GetTrophyPackTrophy"/></summary>
            TrophyGetTrophyPackTrophy,                  //Trophy::getTrophyPackTrophy() function

            /// <summary>Not implemented</summary>
            TssGetData,									//TSS::getData() function

            /// <summary>Not implemented</summary>
            TusGetVariables,                            //TUS::getVariables() function
                                                        /// <summary>Not implemented</summary>
            TusSetVariables,							//TUS::setVariables() function
            /// <summary>Not implemented</summary>
            TusGetFriendsVariable,
            /// <summary>Not implemented</summary>
            TusAddToAndGetVariable,						//TUS::addToAndGetVariable() function
            /// <summary>Not implemented</summary>
            TusTryAndSetVariable,
            /// <summary>Not implemented</summary>       
            TusGetData,									//TUS::getData() function
            /// <summary>Not implemented</summary>
			TusSetData,                                 //TUS::setData() function		
                                                        /// <summary>Not implemented</summary>
            TusDeleteData,								//TUS::deleteData() function
            /// <summary>Not implemented</summary>
            TusGetUsersVariable,							//< <c>TUS::getUsersVariable()</c> function.
            /// <summary>Not implemented</summary>
            TusGetUsersDataStatus,							//< <c>TUS::getUsersDataStatus()</c> function.
            /// <summary>Not implemented</summary>
            TusGetFriendsDataStatus,                        //< <c>TUS::getFriendsDataStatus()</c> function.


            /// <summary>Used by <see cref="UserProfiles.GetNpProfiles"/></summary>
            UserProfileGetNpProfiles,                   //UserProfile::getNpProfiles() function
                                                        /// <summary>Used by <see cref="UserProfiles.GetVerifiedAccountsForTitle"/></summary>
            UserProfileGetVerifiedAccountsForTitle,     //UserProfile::getVerifiedAccountsForTitle() function
                                                        /// <summary>Used by <see cref="UserProfiles.DisplayUserProfileDialog"/></summary>
            UserProfileDisplayUserProfileDialog,        // < <c>UserProfile::displayUserProfileDialog() function
                                                        /// <summary>Used by <see cref="UserProfiles.DisplayGriefReportingDialog"/></summary>
            UserProfileDisplayGriefReportingDialog,     // < <c>UserProfile::displayGriefReportingDialog() function

            /// <summary>Not implemented</summary>
            WordfilterFilterComment,                    //Wordfilter::filterComment() function

            /// <summary>The number of function types</summary>	
            NumFunctionTypes,

            // Custom notification types. These aren't provided by NpToolkit, but are implemented in such a way as to look like normal response objects coming in from NpToolkit.

            /// <summary></summary>	
            NotificationSessionInvitationEvent,

            /// <summary></summary>	
            NotificationPlayTogetherHostEvent,

            /// <summary></summary>	
            NotificationGameCustomDataEvent,

            /// <summary></summary>	
            NotificationLaunchAppEvent,

            // Custom requests
            /// <summary></summary>	
            NpUtilsCheckPlus,

            /// <summary></summary>	
            NpUtilsGetParentalControlInfo
        };

    }
}
