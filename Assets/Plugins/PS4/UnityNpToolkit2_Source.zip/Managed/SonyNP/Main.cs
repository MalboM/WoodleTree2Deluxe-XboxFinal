using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace Sony
{
	namespace NP
	{
		/// <summary>
		/// Main entry point to the NpToolkit plug-in and initialization
		/// </summary>
		public class Main
		{

			#region DLL Import
			[DllImport("UnityNpToolkit2")]
			private static extern void PrxInitialize(InitToolkit initParams, out NativeInitResult initResult, OnPrxCallbackEvent toolkitEventCallback, OnPrxCallbackEvent npRequestEventCallback, out APIResult result);

			[DllImport("UnityNpToolkit2")]
			private static extern void PrxValidateToolkit(ValidationChecks checks, out APIResult result);

			// Termination
			[DllImport("UnityNpToolkit2")]
			private static extern void PrxShutDown();

			// House keeping.
			[DllImport("UnityNpToolkit2")]
			private static extern int PrxUpdate();

			[DllImport("UnityNpToolkit2")]
			private static extern bool PrxAbortRequest(UInt32 npRequestId, out APIResult result);

			#endregion

			[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
			internal delegate void OnPrxCallbackEvent();

			[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
			internal class ValidationChecks
			{
				internal UInt32 expectedNumFunctionTypes;

				public void Init()
				{
                    
                    if (Main.initResult.sceSDKVersion >= 0x06500000)
                    {
                        expectedNumFunctionTypes = (UInt32)FunctionTypes.NumFunctionTypes;
                    }
                    else if(Main.initResult.sceSDKVersion >= 0x05000000)
                    {
                        expectedNumFunctionTypes = (UInt32)FunctionTypes_SDK6_0.NumFunctionTypes;
                    }
                    else
                    {
                        expectedNumFunctionTypes = (UInt32)FunctionTypes_SDK4_5.NumFunctionTypes;
                    }
                }
			}

			// A global struct showing if NpToolkit has been initialised and the SDK version number for the native plugin.
			static internal InitResult initResult;

			/// <summary>
			/// Initialise the NpToolkit2 system
			/// </summary>
			/// <param name="initParams">The initialisation paramaters.</param>
			/// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
			public static InitResult Initialize(InitToolkit initParams)
			{
				APIResult result;

				// Check if the init params are valid and if something isn't this will result in an exception being thrown.
				initParams.CheckValid();

				OnPrxCallbackEvent npToolkitThreadEvent = new OnPrxCallbackEvent(PopulateThread.OnPrxNpToolkitEvent);
				OnPrxCallbackEvent npRequestThreadEvent = new OnPrxCallbackEvent(NpRequestsThread.OnPrxNpRequestEvent);

                NativeInitResult nativeResult = new NativeInitResult();

				PrxInitialize(initParams, out nativeResult, npToolkitThreadEvent, npRequestThreadEvent, out result);

				if (result.RaiseException == true) throw new NpToolkitException(result);

                initResult.Initialise(nativeResult);

                // Validate if the number of function types is correct
                ValidationChecks checks = new ValidationChecks();
                checks.Init();
                PrxValidateToolkit(checks, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

				PopulateThread.Start();
				NpRequestsThread.Start();

				return initResult;
			}

			/// <summary>
			/// Delegate event handler defining the callback event
			/// </summary>
			/// <param name="npEvent"></param>
			public delegate void EventHandler(NpCallbackEvent npEvent);

			/// <summary>
			/// The event called when an async request has been completed or a notification
			/// </summary>
			public static event EventHandler OnAsyncEvent;

			// Handle special events that require the DLL to managed internal structures
			internal static void InternalEventHandler(NpCallbackEvent npEvent)
			{
				// Handle request that have been aborted
				if (npEvent.service == ServiceTypes.Notification)
				{
					if (npEvent.apiCalled == FunctionTypes.NotificationAborted)
					{
						// A pending request has been aborted, so remove it from the internal list
						PendingAsyncRequestList.RequestHasBeenAborted(npEvent.npRequestId);
					}
				}
			}

			// Called from the Populate thread 
			internal static void CallOnAsyncEvent(NpCallbackEvent npEvent)
			{
				// do any internal management here
				InternalEventHandler(npEvent);

				try
				{
					OnAsyncEvent(npEvent);
				}
				catch (Exception e)
				{
					Console.WriteLine("Exception Occured in OnAsyncEvent handler : " + e.Message);
					Console.WriteLine(e.StackTrace);
					throw;  // Throw the expection again as this shouldn't really hide the exception has occured.
				}
				
			}

			/// <summary>
			/// Update function
			/// </summary>
			public static void Update()
			{
				PrxUpdate();
				//PumpAsyncEvents();
			}

			// Use this to call the OnAsyncEvent if doing updates on the Unity script Behaviour thread.
			private static void PumpAsyncEvents()
			{
				//UnityEngine.Profiler.BeginSample("SonyNP PumpAsyncEvents");

				if (OnAsyncEvent != null)
				{
					NpCallbackEvent callbackEvent = PendingCallbackQueue.PopEvent();

					while (callbackEvent != null)
					{
						// do any internal management here
						InternalEventHandler(callbackEvent);

						// Do callback to Unity project
						OnAsyncEvent(callbackEvent);

						// Get next event
						callbackEvent = PendingCallbackQueue.PopEvent();
					}
				}

				//UnityEngine.Profiler.EndSample();
			}

			/// <summary>
			/// Shutdown the NpToolkit2 system
			/// </summary>
			public static void ShutDown()
			{
				PopulateThread.Stop();
				NpRequestsThread.Stop();

				PendingAsyncRequestList.Shutdown();

				PrxShutDown();		
			}

			/// <summary>
			/// Get the pending async requests list. This takes a copy of the list so it is safe to enumerate the list.
			/// </summary>
			/// <returns>A list of pending async requests.</returns>
			public static List<Sony.NP.PendingRequest> GetPendingRequests()
			{
				return PendingAsyncRequestList.PendingRequests;
			}

			/// <summary>
			/// Abort a pending request. A pending request at the top of the list may not abort as processing the request may have already started.
			/// </summary>
			/// <param name="npRequestId">The request to abort.</param>
			/// <returns>Returns true is the request is in the pending list, otherwise returns false.</returns>
			/// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
			public static bool AbortRequest(UInt32 npRequestId)
			{
				if (PendingAsyncRequestList.IsPending(npRequestId) == false)
				{
					return false;
				}

				APIResult result;

				PrxAbortRequest(npRequestId, out result);

				if (result.RaiseException == true) throw new NpToolkitException(result);

				PendingAsyncRequestList.MarkRequestAsAborting(npRequestId);

				return true;
			}

            /// <summary>
			/// Notification that is received when the app is launched from activity feed or live item
			/// </summary>
			public class LaunchAppEventResponse : ResponseBase
            {
                internal string args;

                /// <summary>
                /// Argument assigned from activity feed or live item
                /// </summary>
                public string Args { get { return args; } }
                

                /// <summary>
                /// Read the response data from the plug-in
                /// </summary>
                /// <param name="id">The request id.</param>
                /// <param name="apiCalled">The API called.</param>
                /// <param name="request">The Request object.</param>
                protected internal override void ReadResult(UInt32 id, FunctionTypes apiCalled, RequestBase request)
                {
                    base.ReadResult(id, apiCalled, request);

                    APIResult result;

                    MemoryBuffer readBuffer = BeginReadResponseBuffer(id, apiCalled, out result);

                    if (result.RaiseException == true) throw new NpToolkitException(result);

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.LaunchAppEventBegin);

                    byte[] data = null;
                    UInt32 size = readBuffer.ReadData(ref data);

                    if (size == 0)
                    {
                        args = "";
                    }
                    else
                    {
                        args = System.Text.Encoding.UTF8.GetString(data, 0, data.Length);
                    }

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.LaunchAppEventEnd);

                    EndReadResponseBuffer(readBuffer);
                }
            }
        }
	} // NP
} // Sony
