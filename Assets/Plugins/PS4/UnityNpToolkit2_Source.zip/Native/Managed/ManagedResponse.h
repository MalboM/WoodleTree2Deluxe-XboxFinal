#pragma once

#include "../Includes/SonyCommonIncludes.h"
#include "../ErrorHandling/Errors.h"
#include "MemoryBufferManaged.h"
#include <list>

namespace NPT
{
	// A wrapper class used when the request object needs to be cleaned up
	class RequestCleanupBase
	{
	protected:
		NpToolkit2::Core::RequestBase* m_RequestPtr;
		NpToolkit2::Core::ResponseBase* m_ResponsePtr;

	public:

		RequestCleanupBase(NpToolkit2::Core::RequestBase* requestPtr)
		{
			m_RequestPtr = requestPtr;
			m_ResponsePtr = NULL;
		}

		RequestCleanupBase(NpToolkit2::Core::RequestBase* requestPtr, NpToolkit2::Core::ResponseBase* responsePtr)
		{
			m_RequestPtr = requestPtr;
			m_ResponsePtr = responsePtr;
		}

		virtual ~RequestCleanupBase() {}

		virtual void Cleanup()=0;

		// Only used to indicate if the request was sucessful based on the error code. Some cleanups need to know this
		NpToolkit2::Core::ResponseBase* GetResponse() { return m_ResponsePtr; }
	};

	template<typename T>
	class RequestCleanup : public RequestCleanupBase
	{
	public:

		RequestCleanup(T* requestPtr) : RequestCleanupBase(requestPtr) { }

		RequestCleanup(T* requestPtr, NpToolkit2::Core::ResponseBase* responsePtr) : RequestCleanupBase(requestPtr, responsePtr) { }

		~RequestCleanup()
		{
			T* request = GetRequest();
			delete request;

			// Important - don't select the response object if there is one as this is handled elsewhere
		}

		T* GetRequest() { return static_cast<T*>(m_RequestPtr); }
	};

	enum class FunctionTypeExtended
	{
		invalid = (int)NpToolkit2::Core::FunctionType::numFunctionTypes,

		notificationSessionInvitationEvent,
		notificationPlayTogetherHostEvent,
		notificationGameCustomDataEvent,
		notificationLaunchAppEvent,

		npUtilsCheckPlus,
		npUtilsGetParentalControlInfo,
	};

	// A Map of ResponseBase to ResponseBaseManaged objects.
	// Used in the NpToolkitCallbacks to copy data from the ResponseBase
	// to the matching ResponseBaseManaged object that was passed in on an async call
	class ResponseMap
	{
	private:

		static int AddInternal(NpToolkit2::Core::ResponseBase* responsePtr, UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled, RequestCleanupBase* cleanup);
		static UInt32 AddSynchronousRequest(NpToolkit2::Core::ResponseBase* responsePtr, NpToolkit2::Core::RequestBase& requestPtr, RequestCleanupBase* cleanup);

	public:

		#define MAX_RESPONSES (100)

		struct Map
		{
			bool isActive;
			NpToolkit2::Core::ResponseBase* responsePtr;
			RequestCleanupBase* requestCleanupPtr;
			UInt32 npRequestID;
			NpToolkit2::Core::FunctionType apiCalled;
			MemoryBuffer* buffer;
			int returnCode;
			NpToolkit2::Core::ServerError* serverError;
			bool isNotification;
		};

		static Map* lookupTable;
		static UInt32 nextBlockRequestId;

		static void Initialise();

		static void AddNotification(int returnCode, NpToolkit2::Core::ServerError* serverError, UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled, MemoryBuffer& buffer);
		static void AddMemoryResultsBuffer(MemoryBuffer& buffer, UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled);

		static MemoryBuffer* GetMemoryResultsBuffer(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled);
		static bool IsNotification(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled);

		static void Add(NpToolkit2::Core::ResponseBase* responsePtr, NpToolkit2::Core::RequestBase& request, /*in,out*/ int& npRequestID, RequestCleanupBase* cleanup = NULL);
		static void AddCustomRequest(NpToolkit2::Core::ResponseBase* responsePtr, NpToolkit2::Core::RequestBase& request, int npRequestID );

		static RequestCleanupBase* FindRequestCleanup(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled);
		static NpToolkit2::Core::ResponseBase* Find(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled);
		static NpToolkit2::Core::ResponseBase* FindAndRemove(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled);

		static int GetReturnCode(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled);
		static NpToolkit2::Core::ServerError* GetServerError(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled);
		static bool IsResponseLocked(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled);

		static bool Exists(NpToolkit2::Core::ResponseBase* response);
	};

	class CompletedAsyncEvents
	{
	public:

		struct AsyncEvent
		{
			AsyncEvent()
			{
				customReturnCode = 0;
			}

			NpToolkit2::Core::ServiceType service;				///< Service for which the request belongs to. The Notification service indicates a modification from the system
			NpToolkit2::Core::FunctionType apiCalled;				///< Function called to perform the request. In case of Notification service, the type of notification
			int npToolkitReqId;					///< The request Id returned when the async. request was made
			SceUserServiceUserId userId;		///< The user Id of the user who performed the request
			int customReturnCode;
		};

		static ManagedEventCallback s_PendingResultsCallback;

		static void AddEvent(NpToolkit2::Core::CallbackEvent* event);
		static void AddCustomNotification(FunctionTypeExtended apiCalled, MemoryBuffer& buffer); // Use for custom response objects that aren't part of Nptoolkit but are handled in the same way as normal responses.
		static void AddCustomRequest(UInt32 requestId, UInt32 userId, int returnCode, NpToolkit2::Core::ServiceType serviceType, FunctionTypeExtended apiCalled, MemoryBuffer& buffer);

		static bool PopFirstEvent(AsyncEvent& asyncEvent);

		static void WakeUpManagedThread();

	private:

		static Mutex mutex;
		static std::list<AsyncEvent> asyncEvents;
		static UInt32 nextCustomRequestId;
	};
}