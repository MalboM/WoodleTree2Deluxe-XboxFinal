#include "ManagedResponse.h"

#include "../Source/MarshalResponse.h"
#include "../Source/Core.h"
#include "../Source/Init.h"
#include "../Source/MainNPT.h"

namespace NPT
{
	// Return the response Id, service and apiCalled so the C# code can decide on how to process the response.
	// Also returns the npRequestId which is used to abort the request, but at this point the request had completed.
	// This still needs to be returned to managed the list of pending requests.
	DO_EXPORT( bool, PrxPopFirstResponse ) (Int32* service, Int32* apiCalled, UInt32* npRequestId, Int32* userId, Int32 *customReturnCode )
	{
		CompletedAsyncEvents::AsyncEvent asyncEvent;

		if ( CompletedAsyncEvents::PopFirstEvent(asyncEvent) == false)
		{
			return false;
		}

		*service = (Int32)asyncEvent.service;
		*apiCalled = (Int32)asyncEvent.apiCalled;
		*npRequestId = asyncEvent.npToolkitReqId;
		*userId = asyncEvent.userId;
		*customReturnCode = asyncEvent.customReturnCode;

		// Convert apiCalled to the managed version if this plugin has been built with an older SDK.
		//*apiCalled = RequestBaseManaged::ConvertToManagedEnum(*apiCalled);

		return true;
	}

	DO_EXPORT( void, PrxReadResponseBase ) (UInt32 npRequestId, Int32 apiCalled, Int32* returnCode, bool* locked, APIResult* result)
	{
		// Convert apiCalled to the native version if this plugin has been built with an older SDK.
		//apiCalled = RequestBaseManaged::ConvertFromManagedEnum(apiCalled);

		NpToolkit2::Core::ResponseBase* response = ResponseMap::Find(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);
		bool isNotification = ResponseMap::IsNotification(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);

		if ( response == NULL && isNotification == false)
		{
			ERROR_RESULT(result,"Unable to find response in ResponseMap");
			return;
		}

		*returnCode = ResponseMap::GetReturnCode(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);
		*locked = ResponseMap::IsResponseLocked(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);

		SUCCESS_RESULT(result);
	}

	DO_EXPORT( void, PrxReadResponseBaseLockedState ) (UInt32 npRequestId, Int32 apiCalled, bool* locked, APIResult* result)
	{
		//apiCalled = RequestBaseManaged::ConvertFromManagedEnum(apiCalled);

		NpToolkit2::Core::ResponseBase* response = ResponseMap::Find(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);
		bool isNotification = ResponseMap::IsNotification(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);

		if ( response == NULL && isNotification == false)
		{
			ERROR_RESULT(result,"Unable to find response in ResponseMap");
			return;
		}

		*locked = ResponseMap::IsResponseLocked(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);
		
		SUCCESS_RESULT(result);
	}

	// Called from the C# once the asynchronous or synchronous call is complete. 
	// This means it is safe to delete the response object and cleanup any allocations done for the Request class.
	DO_EXPORT( void, PrxReadResponseCompleted ) (UInt32 npRequestId, Int32 apiCalled, APIResult* result)
	{
		//apiCalled = RequestBaseManaged::ConvertFromManagedEnum(apiCalled);

		RequestCleanupBase* requestCleanup = ResponseMap::FindRequestCleanup(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);
		MemoryBuffer* buffer = ResponseMap::GetMemoryResultsBuffer(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);
		bool isNotification = ResponseMap::IsNotification(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);

		NpToolkit2::Core::ResponseBase* response = ResponseMap::FindAndRemove(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);

		// Response base can be null for notification responses
		if ( response == NULL && isNotification == false)
		{
			ERROR_RESULT(result,"Unable to find response in ResponseMap");
			return;
		}

		if ( requestCleanup != NULL)
		{
			requestCleanup->Cleanup();
			delete requestCleanup;
		}

		if ( buffer != NULL )
		{
			// Add the memory buffer back into the queue so it can be re-used.
			buffer->Reset();
			MemoryBuffer::ReleaseBuffer(*buffer);
		}

		// Free up the memory used by the response object
		MarshalResponse::DeleteResponse(response, (NpToolkit2::Core::FunctionType)apiCalled);

		SUCCESS_RESULT(result);
	}

	DO_EXPORT( bool, PrxReadHasServerError ) (UInt32 npRequestId, Int32 apiCalled, APIResult* result )
	{
		//apiCalled = RequestBaseManaged::ConvertFromManagedEnum(apiCalled);

		NpToolkit2::Core::ResponseBase* response = ResponseMap::Find(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);
		bool isNotification = ResponseMap::IsNotification(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);

		if ( response == NULL && isNotification == false)
		{
			ERROR_RESULT(result,"Unable to find response in ResponseMap");
			return false;
		}

		SUCCESS_RESULT(result);

		NpToolkit2::Core::ServerError* serverError =  ResponseMap::GetServerError(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);

		if ( serverError == NULL )
		{
			return false;
		}

		return true;
	}

	#define EXPECTED_JSON_DATA_LEN (512)
	DO_EXPORT( void, PrxReadServerError ) (UInt32 npRequestId, Int32 apiCalled, Int64* webApiNextAvailableTime, Int32* httpStatusCode, char jsonData[EXPECTED_JSON_DATA_LEN], APIResult* result )
	{
		//apiCalled = RequestBaseManaged::ConvertFromManagedEnum(apiCalled);

		NpToolkit2::Core::ResponseBase* response = ResponseMap::Find(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);
		bool isNotification = ResponseMap::IsNotification(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);

		if ( response == NULL && isNotification == false)
		{
			ERROR_RESULT(result,"Unable to find response in ResponseMap");
			return;
		}

		*webApiNextAvailableTime = 0;
		*httpStatusCode = 0;
		
		NpToolkit2::Core::ServerError* serverError = ResponseMap::GetServerError(npRequestId, (NpToolkit2::Core::FunctionType)apiCalled);

		memcpy(jsonData, serverError->jsonData, EXPECTED_JSON_DATA_LEN); //ServerError::JSON_DATA_MAX_LEN);

		*webApiNextAvailableTime =  serverError->webApiNextAvailableTime;
		*httpStatusCode =  serverError->httpStatusCode;

		SUCCESS_RESULT(result);
	}

	ResponseMap::Map* ResponseMap::lookupTable = NULL;
	UInt32 ResponseMap::nextBlockRequestId = g_synchronousRequestIdStart;

	void ResponseMap::Initialise()
	{
		if ( lookupTable == NULL )
		{
			lookupTable = new Map[MAX_RESPONSES];
		}

		for(int i =0; i < MAX_RESPONSES; i++)
		{
			lookupTable[i].isActive = false;
			lookupTable[i].responsePtr = NULL;
			lookupTable[i].npRequestID = 0;
			lookupTable[i].isNotification = false;
		}
	}

	int ResponseMap::AddInternal(NpToolkit2::Core::ResponseBase* responsePtr, UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled, RequestCleanupBase* cleanup)
	{
		for(int i = 0; i < MAX_RESPONSES; i++)
		{
			if ( lookupTable[i].isActive == false )
			{
				lookupTable[i].isActive = true;
				lookupTable[i].responsePtr = responsePtr;
				lookupTable[i].requestCleanupPtr = cleanup;
				lookupTable[i].npRequestID = npRequestID;
				lookupTable[i].apiCalled = apiCalled;
				lookupTable[i].buffer = NULL;
				lookupTable[i].isNotification = false;
				return i;
			}
		}

		return -1;
	}

	void ResponseMap::Add(NpToolkit2::Core::ResponseBase* responsePtr, NpToolkit2::Core::RequestBase& request, /*in,out*/ int& npRequestID, RequestCleanupBase* cleanup )
	{
		ResponseMapAutoLock autoLock;

		if ( request.async == true )
		{
			AddInternal(responsePtr, npRequestID, request.getFunctionType(), cleanup);
		}
		else
		{
			npRequestID = AddSynchronousRequest(responsePtr, request, cleanup);

			APIResult result;
			MemoryBuffer* buffer = &MarshalResponse::WriteToBuffer(responsePtr, request.getFunctionType(), &result);
			ResponseMap::AddMemoryResultsBuffer(*buffer,npRequestID, request.getFunctionType());
		}
	}		

	void ResponseMap::AddCustomRequest(NpToolkit2::Core::ResponseBase* responsePtr, NpToolkit2::Core::RequestBase& request, int npRequestID )
	{
		ResponseMapAutoLock autoLock;

		AddInternal(responsePtr, npRequestID, request.getFunctionType(), NULL);
	}

	UInt32 ResponseMap::AddSynchronousRequest(NpToolkit2::Core::ResponseBase* responsePtr, NpToolkit2::Core::RequestBase& request, RequestCleanupBase* cleanup)
	{
		UInt32 id = nextBlockRequestId;
		AddInternal(responsePtr, id, request.getFunctionType(), cleanup);
		
		nextBlockRequestId++;

		return id;
	}

	void ResponseMap::AddNotification(int returnCode, NpToolkit2::Core::ServerError* serverError, UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled, MemoryBuffer& buffer)
	{
		int index = AddInternal(NULL, npRequestID, apiCalled, NULL);

		if ( index >= 0 )
		{
			lookupTable[index].buffer = &buffer;
			lookupTable[index].returnCode = returnCode;
			lookupTable[index].serverError = serverError;
			lookupTable[index].isNotification = true;
		}
	}

	void ResponseMap::AddMemoryResultsBuffer(MemoryBuffer& buffer, UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled)
	{
		for(int i = 0; i < MAX_RESPONSES; i++)
		{
			if ( lookupTable[i].isActive == true && lookupTable[i].npRequestID == npRequestID && lookupTable[i].apiCalled == apiCalled )
			{
				lookupTable[i].buffer = &buffer;
				return;
			}
		}
	}

	MemoryBuffer* ResponseMap::GetMemoryResultsBuffer(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled)
	{
		for(int i = 0; i < MAX_RESPONSES; i++)
		{
			if ( lookupTable[i].isActive == true && lookupTable[i].npRequestID == npRequestID && lookupTable[i].apiCalled == apiCalled )
			{
				return lookupTable[i].buffer;
			}
		}

		return NULL;
	}

	bool ResponseMap::IsNotification(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled)
	{
		for(int i = 0; i < MAX_RESPONSES; i++)
		{
			if ( lookupTable[i].isActive == true && lookupTable[i].npRequestID == npRequestID && lookupTable[i].apiCalled == apiCalled )
			{
				return lookupTable[i].isNotification;
			}
		}

		return false;
	}
		
	RequestCleanupBase* ResponseMap::FindRequestCleanup(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled)
	{
		for(int i = 0; i < MAX_RESPONSES; i++)
		{
			if ( lookupTable[i].isActive == true && lookupTable[i].npRequestID == npRequestID && lookupTable[i].apiCalled == apiCalled )
			{
				return lookupTable[i].requestCleanupPtr;
			}
		}

		return NULL;
	}

	NpToolkit2::Core::ResponseBase* ResponseMap::Find(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled)
	{
		for(int i = 0; i < MAX_RESPONSES; i++)
		{
			if (lookupTable[i].isActive == true && lookupTable[i].npRequestID == npRequestID && lookupTable[i].apiCalled == apiCalled )
			{
				return lookupTable[i].responsePtr;
			}
		}

		return NULL;
	}

	int ResponseMap::GetReturnCode(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled)
	{
		for(int i = 0; i < MAX_RESPONSES; i++)
		{
			if (lookupTable[i].isActive == true && lookupTable[i].npRequestID == npRequestID && lookupTable[i].apiCalled == apiCalled )
			{
				if( lookupTable[i].responsePtr != NULL)
				{
					return lookupTable[i].responsePtr->getReturnCode();
				}

				return lookupTable[i].returnCode;
			}
		}

		return 0;
	}

	NpToolkit2::Core::ServerError* ResponseMap::GetServerError(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled)
	{
		for(int i = 0; i < MAX_RESPONSES; i++)
		{
			if (lookupTable[i].isActive == true && lookupTable[i].npRequestID == npRequestID && lookupTable[i].apiCalled == apiCalled )
			{
				if( lookupTable[i].responsePtr != NULL)
				{
					return lookupTable[i].responsePtr->getServerError();
				}

				return lookupTable[i].serverError;
			}
		}

		return NULL;
	}

	bool ResponseMap::IsResponseLocked(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled)
	{
		for(int i = 0; i < MAX_RESPONSES; i++)
		{
			if (lookupTable[i].isActive == true && lookupTable[i].npRequestID == npRequestID && lookupTable[i].apiCalled == apiCalled )
			{
				if( lookupTable[i].responsePtr != NULL)
				{
                    if( NpRequests::IsPendingCustomRequest(lookupTable[i].npRequestID) == true )
                    {
                        return true; // If its in the custom request queue then it is locked.
                    }

					return lookupTable[i].responsePtr->isLocked();
				}

				return false;
			}
		}

		return false;
	}

	NpToolkit2::Core::ResponseBase* ResponseMap::FindAndRemove(UInt32 npRequestID, NpToolkit2::Core::FunctionType apiCalled)
	{
		for(int i = 0; i < MAX_RESPONSES; i++)
		{
			if ( lookupTable[i].isActive == true && lookupTable[i].npRequestID == npRequestID && lookupTable[i].apiCalled == apiCalled  )
			{
				NpToolkit2::Core::ResponseBase* response = lookupTable[i].responsePtr;

				lookupTable[i].isActive = false;
				lookupTable[i].responsePtr = NULL;
				lookupTable[i].npRequestID = 0;
				lookupTable[i].apiCalled = NpToolkit2::Core::FunctionType::invalid;
				lookupTable[i].requestCleanupPtr = 0;
				lookupTable[i].isNotification = false;

				return response;
			}
		}

		return NULL;
	}

	bool ResponseMap::Exists(NpToolkit2::Core::ResponseBase* response)
	{
		for(int i = 0; i < MAX_RESPONSES; i++)
		{
			if ( lookupTable[i].responsePtr == response)
			{
				return true;
			}
		}

		return false;
	}

	std::list<CompletedAsyncEvents::AsyncEvent> CompletedAsyncEvents::asyncEvents;

	Mutex CompletedAsyncEvents::mutex;
	UInt32 CompletedAsyncEvents::nextCustomRequestId = g_customNotificationRequestIdStart;
	ManagedEventCallback CompletedAsyncEvents::s_PendingResultsCallback = NULL;

	void CompletedAsyncEvents::WakeUpManagedThread()
	{
		if ( s_PendingResultsCallback != NULL )
		{
			s_PendingResultsCallback();
		}
	}

	void CompletedAsyncEvents::AddEvent(NpToolkit2::Core::CallbackEvent* event)
	{
		// Note: Can't keep hold of the event pointer as this is owned by NpToolkit and may get freed up.
		NpToolkit2::Core::ResponseBase* response = event->response;
				
		// IMPORTANT : The Response pointer if allocated by the application will remain valid until the plugin deletes it in PrxReadResponseCompleted.
		//           : In the case of notifications, it will be allocated by the NpToolkit2 library and destroyed upon callbacks return;
		//           : Therefore for notification it is necessary to write the memory buffer of the Response object so it can be read 
		//           : by the C# dll on a seperate thread, in the same way all other response objects are handled.
		//           : However this still needs a ResponseBase instance as that contains the return code and server error, so in the case of notifications
		//           : the base class needs copying. 

		APIResult result;
	    MemoryBuffer* buffer;

		buffer = &MarshalResponse::WriteToBuffer(response, event->apiCalled, &result);
		
		int returnCode = response->getReturnCode();
		NpToolkit2::Core::ServerError* newServerError = NULL;
		
		if ( response->getServerError() )
		{
			newServerError = new NpToolkit2::Core::ServerError();
			Core::CopyServerError(*newServerError, *response->getServerError() );
		}

		if ( event->service == NpToolkit2::Core::ServiceType::notification )
		{
			// For notifications 
			//NpToolkit2::Core::ServerError* newServerError = new NpToolkit2::Core::ServerError();
			//Core::CopyServerError(serverError, *source.getServerError() );
			//NpToolkit2::Core::ResponseBase *notificationResponse = new NpToolkit2::Core::ResponseBase();
			//Core::CopyResponseBase(*notificationResponse, *response);

			ResponseMap::AddNotification(returnCode, newServerError, event->npToolkitReqId, event->apiCalled, *buffer);
		}
		else
		{
			ResponseMap::AddMemoryResultsBuffer(*buffer, event->npToolkitReqId, event->apiCalled);
		}

		AsyncEvent asyncEvent;
		asyncEvent.service = event->service;
		asyncEvent.apiCalled = event->apiCalled;
		asyncEvent.npToolkitReqId = event->npToolkitReqId;
		asyncEvent.userId = event->userId;

		mutex.Lock();

		asyncEvents.push_back(asyncEvent);

		mutex.UnLock();

		WakeUpManagedThread();
	}

	// Use for custom response objects that aren't part of Nptoolkit but are handled in the same way as normal responses.
	void CompletedAsyncEvents::AddCustomNotification(FunctionTypeExtended apiCalledExtended, MemoryBuffer& buffer)
	{
		mutex.Lock();

		UInt32 requestId = nextCustomRequestId;
		nextCustomRequestId++;

		NpToolkit2::Core::FunctionType apiCalled = (NpToolkit2::Core::FunctionType)((int)apiCalledExtended);
		ResponseMap::AddNotification(0, NULL, requestId, apiCalled, buffer);

		AsyncEvent asyncEvent;
		asyncEvent.service = NpToolkit2::Core::ServiceType::notification;
		asyncEvent.apiCalled = apiCalled;
		asyncEvent.npToolkitReqId = requestId;
		asyncEvent.userId = Init::GetPrimaryUserId();

		asyncEvents.push_back(asyncEvent);

		mutex.UnLock();

		WakeUpManagedThread();
	}

	void CompletedAsyncEvents::AddCustomRequest(UInt32 requestId, UInt32 userId, int returnCode, NpToolkit2::Core::ServiceType serviceType, FunctionTypeExtended apiCalled, MemoryBuffer& buffer)
	{
		mutex.Lock();

		NpToolkit2::Core::ResponseBase* response = ResponseMap::Find(requestId, (NpToolkit2::Core::FunctionType)apiCalled);

		if ( response != NULL )
		{
			// currently doesn't work- Not possible to set a return code.
			//response->setReturnCode(returnCode);
		}

		ResponseMap::AddMemoryResultsBuffer(buffer, requestId, (NpToolkit2::Core::FunctionType)apiCalled);

		AsyncEvent asyncEvent;
		asyncEvent.service = serviceType;
		asyncEvent.apiCalled = (NpToolkit2::Core::FunctionType)apiCalled;
		asyncEvent.npToolkitReqId = requestId;
		asyncEvent.userId = userId;
		asyncEvent.customReturnCode = returnCode;

		asyncEvents.push_back(asyncEvent);

		mutex.UnLock();

		WakeUpManagedThread();
	}

	bool CompletedAsyncEvents::PopFirstEvent(AsyncEvent& asyncEvent)
	{
		mutex.Lock();

		if(asyncEvents.empty() == false)
		{
			asyncEvent = asyncEvents.front();
			asyncEvents.pop_front();

			mutex.UnLock();
			return true;
		}

		mutex.UnLock();
		return false;
	}


}