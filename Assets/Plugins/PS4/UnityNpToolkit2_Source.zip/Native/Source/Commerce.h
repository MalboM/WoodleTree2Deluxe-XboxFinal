#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{

// Typedefs for differences between SDK 4.0 and SDK 4.5
#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
	typedef NpToolkit2::Commerce::CategoryLabel CategoryLabel;
	#define CATEGORY_LABEL_MAX_LEN NpToolkit2::Commerce::CategoryLabel::CATEGORY_LABEL_MAX_LEN

	typedef NpToolkit2::Commerce::ProductLabel ProductLabel;
	#define PRODUCT_LABEL_MAX_LEN NpToolkit2::Commerce::ProductLabel::PRODUCT_LABEL_MAX_LEN

	typedef NpToolkit2::Commerce::SkuLabel SkuLabel;
	#define SKU_LABEL_MAX_LEN NpToolkit2::Commerce::SkuLabel::SKU_LABEL_MAX_LEN

	//typedef NpToolkit2::Commerce::ServiceEntitlementLabel ServiceEntitlementLabel;
	#define SERVICE_ENTITLEMENT_LABEL_MAX_LEN NpToolkit2::Commerce::ServiceEntitlementLabel::SERVICE_ENTITLEMENT_LABEL_MAX_LEN

	#define MAX_PRODUCTS NpToolkit2::Commerce::Request::GetProducts::MAX_PRODUCTS

	#define MAX_TARGETS NpToolkit2::Commerce::Request::DisplayCheckoutDialog::MAX_TARGETS

#else
	typedef NpToolkit2::Commerce::Request::CategoryId CategoryLabel;
	#define CATEGORY_LABEL_MAX_LEN NpToolkit2::Commerce::Request::CategoryId::CATEGORY_ID_LEN

	typedef NpToolkit2::Commerce::Request::ProductId ProductLabel;
	#define PRODUCT_LABEL_MAX_LEN NpToolkit2::Commerce::Request::ProductId::PRODUCT_ID_LEN

	typedef NpToolkit2::Commerce::Request::SkuId SkuLabel;
	#define SKU_LABEL_MAX_LEN NpToolkit2::Commerce::Request::SkuId::SKU_ID_LEN

	#define SERVICE_ENTITLEMENT_LABEL_MAX_LEN NpToolkit2::Commerce::Request::ConsumeServiceEntitlement::ENTITLEMENT_ID_LEN

	#define MAX_PRODUCTS NpToolkit2::Commerce::Request::GetProducts::MAX_PRODUCT_IDS

	#define MAX_TARGETS NpToolkit2::Commerce::Request::DisplayCheckoutDialog::MAX_SKU_IDS
#endif

	// The size of the values marshalled across from the C#. This needs to be hardcoded to the largest value, which is currently those set in SDK 4.0
	#define MARSHALED_CATEGORY_LABEL_MAX_LEN 55
	#define MARSHALED_PRODUCT_LABEL_MAX_LEN 47
	#define MARSHALED_SKU_LABEL_MAX_LEN 55
	#define MARSHALED_SERVICE_ENTITLEMENT_LABEL_MAX_LEN 31

	struct CategoryLabelManaged
	{
	public:
		char value[MARSHALED_CATEGORY_LABEL_MAX_LEN + 1];
		
		void CopyTo(CategoryLabel &destination);
	};
	
	class GetCategoriesManaged : public RequestBaseManaged
	{
	public:

		UInt64		numCategories;					///< Set to 0 to just get information about the root category
		CategoryLabelManaged	categoryLabels[NpToolkit2::Commerce::Request::GetCategories::MAX_CATEGORIES];	///< The IDs of the categories to obtain the information about	

		void CopyTo(NpToolkit2::Commerce::Request::GetCategories &destination);
	};	

	struct ProductLabelManaged
	{
	public:
		char value[MARSHALED_PRODUCT_LABEL_MAX_LEN + 1];

		void CopyTo(ProductLabel &destination);
	};

	struct SkuLabelManaged
	{
	public:
		char value[MARSHALED_SKU_LABEL_MAX_LEN + 1];

		void CopyTo(SkuLabel &destination);
	};

	struct ServiceEntitlementLabelManaged
	{
		char value[MARSHALED_SERVICE_ENTITLEMENT_LABEL_MAX_LEN + 1];

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		void CopyTo(sce::Toolkit::NP::Commerce::ServiceEntitlementLabel &destination);
#endif
	};

	struct CheckoutTargetManaged
	{
	public:
		ProductLabelManaged productLabel;			///< The product label of the target to show on the dialog.
		SkuLabelManaged	skuLabel;				///< Optional (mandatory if <c><i>serviceLabel</i></c> is provided). The sku label of the product target to show on the dialog.
		SceNpServiceLabel serviceLabel;		///< Optional. The service label of the product and sku to show on the dialog, in case more than one service label is configured.

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		void CopyTo(NpToolkit2::Commerce::Request::CheckoutTarget &destination);
#endif
	};

	struct DownloadListTargetManaged
	{
	public:
		ProductLabelManaged productLabel;			///< The product label of the target to show on the dialog.
		SkuLabelManaged	skuLabel;				///< Optional (mandatory if <c><i>serviceLabel</i></c> is provided). The sku label of the product target to show on the dialog.

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		void CopyTo(NpToolkit2::Commerce::Request::DownloadListTarget &destination);
#endif
	};

	class GetProductsManaged : public RequestBaseManaged
	{
	public:

		UInt64					numProducts;	  // Number of IDs set in productIds. If 0 is specified, all products up to pageSize will be retrieved
		ProductLabelManaged		productLabels[MAX_PRODUCTS];	///< IDs if the specific products we want to retrieve
		
		UInt64					numCategories;	
		CategoryLabelManaged	categoryLabels[NpToolkit2::Commerce::Request::GetProducts::MAX_CATEGORIES];	///< The IDs of the categories to obtain products from. Ignored if numProductIds is greater than 0
		
		UInt32					offset;							///< If many products exist, paging can be used. This is the starting index
		UInt32					pageSize;						///< Maximum number of entitlements to return. Defaults to <c>DEFAULT_PAGE_SIZE</c>
		NpToolkit2::Commerce::Request::ProductSortOrder		sortOrder;						///< Sorting order in which the products are returned
		NpToolkit2::Commerce::Request::ProductSortDirection	sortDirection;					///< Sorting direction in which the products are returned
		bool					keepHtmlTags;					///< Keep HTML tags in the product long description. false by default
		bool					useCurrencySymbol;				///< Use currency symbol (example: $), instead currency code (example: USD). false by default

		void CopyTo(NpToolkit2::Commerce::Request::GetProducts &destination);
	};	

	class GetServiceEntitlementsManaged : public RequestBaseManaged
	{
	public:
		
		UInt32					offset;
		UInt32					pageSize;

		void CopyTo(NpToolkit2::Commerce::Request::GetServiceEntitlements &destination);
	};

	class ConsumeServiceEntitlementManaged : public RequestBaseManaged
	{
	public:

		ServiceEntitlementLabelManaged		entitlementLabel;	
		UInt32		consumedCount;

		void CopyTo(NpToolkit2::Commerce::Request::ConsumeServiceEntitlement &destination);
	};

	class DisplayCategoryBrowseDialogManaged : public RequestBaseManaged
	{
	public:
		CategoryLabelManaged categoryLabel;

		void CopyTo(NpToolkit2::Commerce::Request::DisplayCategoryBrowseDialog &destination);
	};

	class DisplayProductBrowseDialogManaged : public RequestBaseManaged
	{
	public:

		ProductLabelManaged productLabel;

		void CopyTo(NpToolkit2::Commerce::Request::DisplayProductBrowseDialog &destination);
	};

	class DisplayVoucherCodeInputDialogManaged : public RequestBaseManaged
	{
	public:

		char voucherCode[NpToolkit2::Commerce::Request::DisplayVoucherCodeInputDialog::VOUCHER_CODE_LEN + 1];

		void CopyTo(NpToolkit2::Commerce::Request::DisplayVoucherCodeInputDialog &destination);
	};

	class DisplayCheckoutDialogManaged : public RequestBaseManaged
	{
	public:

		UInt64 numTargets;
		CheckoutTargetManaged targets[MAX_TARGETS];

		void CopyTo(NpToolkit2::Commerce::Request::DisplayCheckoutDialog &destination);
		bool Validate(APIResult* result);
	};

	class DisplayDownloadListDialogManaged : public RequestBaseManaged
	{
	public:

		UInt64 numTargets;
		DownloadListTargetManaged targets[MAX_TARGETS];

		void CopyTo(NpToolkit2::Commerce::Request::DisplayDownloadListDialog &destination);
	};

	class DisplayJoinPlusDialogManaged : public RequestBaseManaged
	{
	public:

		UInt64 features;  // Defualts to SCE_NP_PLUS_FEATURE_REALTIME_MULTIPLAY.

		void CopyTo(NpToolkit2::Commerce::Request::DisplayJoinPlusDialog &destination);
	};

	class SetPsStoreIconDisplayStateManaged : public RequestBaseManaged
	{
	public:

		SceNpCommercePsStoreIconPos	iconPosition;
		bool						showIcon;		

		void CopyTo(NpToolkit2::Commerce::Request::SetPsStoreIconDisplayState &destination);
	};

	class Commerce
	{
	public:

		typedef NpToolkit2::Commerce::Categories NptCategories;
		typedef NpToolkit2::Core::Response<NptCategories> NptCategoriesResponse;

		typedef NpToolkit2::Commerce::Products NptProducts;
		typedef NpToolkit2::Core::Response<NptProducts> NptProductsResponse;

		typedef NpToolkit2::Commerce::ServiceEntitlements NptServiceEntitlements;
		typedef NpToolkit2::Core::Response<NptServiceEntitlements> NptServiceEntitlementsResponse;

		//Requests
		static int GetCategories(GetCategoriesManaged* managedRequest, APIResult* result);
		static int GetProducts(GetProductsManaged* managedRequest, APIResult* result);
		static int GetServiceEntitlements(GetServiceEntitlementsManaged* managedRequest, APIResult* result);
		static int ConsumeServiceEntitlement(ConsumeServiceEntitlementManaged* managedRequest, APIResult* result);
		static int DisplayCategoryBrowseDialog(DisplayCategoryBrowseDialogManaged* managedRequest, APIResult* result);
		static int DisplayProductBrowseDialog(DisplayProductBrowseDialogManaged* managedRequest, APIResult* result);
		static int DisplayVoucherCodeInputDialog(DisplayVoucherCodeInputDialogManaged* managedRequest, APIResult* result);
		static int DisplayCheckoutDialog(DisplayCheckoutDialogManaged* managedRequest, APIResult* result);
		static int DisplayDownloadListDialog(DisplayDownloadListDialogManaged* managedRequest, APIResult* result);
		static int DisplayJoinPlusDialog(DisplayJoinPlusDialogManaged* managedRequest, APIResult* result);
		static int SetPsStoreIconDisplayState(SetPsStoreIconDisplayStateManaged* managedRequest, APIResult* result);

		// Marshal methods
		static void MarshalCategories(NptCategoriesResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalProducts(NptProductsResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalServiceEntitlements(NptServiceEntitlementsResponse* response, MemoryBuffer& buffer, APIResult* result);

		// Write Methods
		static void WriteToBuffer(const NpToolkit2::Commerce::Category& category, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::Commerce::SubCategory& subCategory, MemoryBuffer& buffer);

		static void WriteToBuffer(const CategoryLabel& categoryLabel, MemoryBuffer& buffer);
		static void WriteToBuffer(const ProductLabel& productLabel, MemoryBuffer& buffer);
		static void WriteToBuffer(const SkuLabel& skuLabel, MemoryBuffer& buffer);

#if (SCE_ORBIS_SDK_VERSION >= 0x04500000)
		static void WriteToBuffer(const NpToolkit2::Commerce::ServiceEntitlementLabel& serviceEntitlementLabel, MemoryBuffer& buffer);
#endif

		static void WriteToBuffer(const NpToolkit2::Commerce::Product& product, bool hasDetails, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::Commerce::ProductDetails& productDetails, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::Commerce::SkuInfo& skuInfo, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::Commerce::RatingDescriptor& ratingDescriptor, MemoryBuffer& buffer);

		static void WriteToBuffer(const NpToolkit2::Commerce::ServiceEntitlement& serviceEntitlement, MemoryBuffer& buffer);

	};
}





