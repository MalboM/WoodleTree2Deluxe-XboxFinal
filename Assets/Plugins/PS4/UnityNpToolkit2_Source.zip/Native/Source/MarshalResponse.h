#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	class MarshalResponse
	{
	public:
		
		static void Read(UInt32 npRequestId, NpToolkit2::Core::FunctionType apiCalled, MemoryBufferManaged* outBuffer, APIResult* result);
		static MemoryBuffer& WriteToBuffer(NpToolkit2::Core::ResponseBase* response, NpToolkit2::Core::FunctionType apiCalled, APIResult* result);

		// Delete
		static void DeleteResponse(NpToolkit2::Core::ResponseBase* response, NpToolkit2::Core::FunctionType apiCalled);
	};
}





