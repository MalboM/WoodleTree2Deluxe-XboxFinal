
#include "Tus.h"

#include "Core.h"

namespace NPT
{
	DO_EXPORT( int, PrxTusSetVariables ) (TusSetVariablesManaged* managedRequest, APIResult* result)
	{
		return TUS::SetVariables(managedRequest, result);
	}

	DO_EXPORT( int, PrxTusGetVariables ) (TusGetVariablesManaged* managedRequest, APIResult* result)
	{
		return TUS::GetVariables(managedRequest, result);
	}

	DO_EXPORT( int, PrxTusAddToAndGetVariable ) (TusAddToAndGetVariableManaged* managedRequest, APIResult* result)
	{
		return TUS::AddToAndGetVariable(managedRequest, result);
	}

	DO_EXPORT( int, PrxTusSetData ) (TusSetDataManaged* managedRequest, APIResult* result)
	{
		return TUS::SetData(managedRequest, result);
	}

	DO_EXPORT( int, PrxTusGetData ) (TusGetDataManaged* managedRequest, APIResult* result)
	{
		return TUS::GetData(managedRequest, result);
	}

	DO_EXPORT( int, PrxTusDeleteData ) (TusDeleteDataManaged* managedRequest, APIResult* result)
	{
		return TUS::DeleteData(managedRequest, result);
	}

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
	DO_EXPORT( int, PrxTusTryAndSetVariable ) (TusTryAndSetVariableManaged* managedRequest, APIResult* result)
	{
		return TUS::TryAndSetVariable(managedRequest, result);
	}

	DO_EXPORT( int, PrxTusGetFriendsVariable ) (TusGetFriendsVariableManaged* managedRequest, APIResult* result)
	{
		return TUS::GetFriendsVariable(managedRequest, result);
	}

	DO_EXPORT( int, PrxTusGetUsersVariable ) (TusGetUsersVariableManaged* managedRequest, APIResult* result)
	{
		return TUS::GetUsersVariable(managedRequest, result);
	}

	DO_EXPORT( int, PrxTusGetUsersDataStatus ) (TusGetUsersDataStatusManaged* managedRequest, APIResult* result)
	{
		return TUS::GetUsersDataStatus(managedRequest, result);
	}

	DO_EXPORT( int, PrxTusGetFriendsDataStatus ) (TusGetFriendsDataStatusManaged* managedRequest, APIResult* result)
	{
		return TUS::GetFriendsDataStatus(managedRequest, result);
	}
#endif

	void VirtualUserIDManaged::CopyTo(SceNpTusVirtualUserId &destination)
	{
		memcpy_s(destination.data, SCE_NP_ONLINEID_MAX_LENGTH, virtualUserID, SCE_NP_ONLINEID_MAX_LENGTH); // SceNpTusVirtualUserId structure contains a termninating char
		destination.term = 0;  // Make sure string is terminated
	}

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
	void TusUserInputManaged::CopyTo(NpToolkit2::TUS::Request::TusUserInput &destination)
	{
		destination.isVirtual = isVirtual;

		if (isVirtual == true)
		{
			virtualId.CopyTo(destination.virtualId);
		}
		else
		{
			destination.realId = realId;
		}
	}
#endif

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
	void TusVariableInputManaged::CopyTo(NpToolkit2::TUS::Request::TusVariableInput &destination)
	{
		destination.value = value;
		destination.slotId = slotId;
	}
#else
	void TusVariableInputManaged::CopyTo(NpToolkit2::TUS::TusVariable &destination)
	{
		destination.value = value;
		destination.slotId = slotId;
	}
#endif

	void TusSetVariablesManaged::CopyTo(NpToolkit2::TUS::Request::SetVariables &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		tusUser.CopyTo(destination.tusUser);
#else
		destination.isVirtualUser = tusUser.isVirtual;

		if (destination.isVirtualUser == true)
		{
			tusUser.virtualId.CopyTo(destination.virtualUserID);
		}
		else
		{
			destination.targetUser = tusUser.realId;
		}
#endif

		destination.numVars = numVars;

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		destination.variables = new NpToolkit2::TUS::Request::TusVariableInput[numVars];

		for(int i = 0; i < numVars; i++)
		{
			variables[i].CopyTo(destination.variables[i]);
		}
#else
		for(int i = 0; i < numVars; i++)
		{
			variables[i].CopyTo(destination.vars[i]);
		}
#endif
	}

	class TusSetVariablesCleanup : public RequestCleanup<NpToolkit2::TUS::Request::SetVariables>
	{
	public:

		TusSetVariablesCleanup(NpToolkit2::TUS::Request::SetVariables* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
			NpToolkit2::TUS::Request::SetVariables* request = GetRequest();

			if (request->variables != NULL)
			{
				delete[] request->variables;
			}
#endif
		}
	};

	void TusGetVariablesManaged::CopyTo(NpToolkit2::TUS::Request::GetVariables &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		tusUser.CopyTo(destination.tusUser);
#else
		destination.isVirtualUser = tusUser.isVirtual;

		if (destination.isVirtualUser == true)
		{
			tusUser.virtualId.CopyTo(destination.virtualUserID);
		}
		else
		{
			destination.targetUser = tusUser.realId;
		}
#endif

		destination.numSlots = numSlots;

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		destination.slots = new SceNpTusSlotId[numSlots];

		for(int i = 0; i < numSlots; i++)
		{
			destination.slots[i] = slots[i];
		}
#else
		for(int i = 0; i < numSlots; i++)
		{
			destination.slotIds[i] = slots[i];
		}
#endif

		destination.forCrossSave = forCrossSave;
	}

	class TusGetVariablesCleanup : public RequestCleanup<NpToolkit2::TUS::Request::GetVariables>
	{
	public:

		TusGetVariablesCleanup(NpToolkit2::TUS::Request::GetVariables* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
			NpToolkit2::TUS::Request::GetVariables* request = GetRequest();

			if (request->slots != NULL)
			{
				delete[] request->slots;
			}
#endif
		}
	};

	void TusDataContentionManaged::CopyTo(NpToolkit2::TUS::DataContention &destination)
	{
		destination.lastChangedDate = lastChangedDate;
		destination.requiredLastChangeUser = requiredLastChangeUser;
	};

	void TusAddToAndGetVariableManaged::CopyTo(NpToolkit2::TUS::Request::AddToAndGetVariable &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		tusUser.CopyTo(destination.tusUser);
#else
		destination.isVirtualUser = tusUser.isVirtual;

		if (destination.isVirtualUser == true)
		{
			tusUser.virtualId.CopyTo(destination.virtualUserID);
		}
		else
		{
			destination.targetUser = tusUser.realId;
		}
#endif

		var.CopyTo(destination.var);

		dataContention.CopyTo(destination.dataContention);

		destination.forCrossSave = forCrossSave;
	}

	void TusSetDataManaged::CopyTo(NpToolkit2::TUS::Request::SetData &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		tusUser.CopyTo(destination.tusUser);
#else
		destination.isVirtualUser = tusUser.isVirtual;

		if (destination.isVirtualUser == true)
		{
			tusUser.virtualId.CopyTo(destination.virtualUserID);
		}
		else
		{
			destination.targetUser = tusUser.realId;
		}
#endif

		UInt8* buffer = new UInt8[dataSize];
		memcpy(buffer, data, dataSize); 

		destination.data.buffer = buffer;
		destination.data.bufferSize = dataSize;

		destination.supplementaryInfoSize = supplementaryInfoSize;
		memcpy_s(destination.supplementaryInfo, SCE_NP_TUS_DATA_INFO_MAX_SIZE, supplementaryInfo, supplementaryInfoSize);

		destination.dataContention.lastChangedDate = dataContention.lastChangedDate;
		destination.dataContention.requiredLastChangeUser = dataContention.requiredLastChangeUser;

		destination.slotId = slotId;
	}

	class TusSetDataCleanup : public RequestCleanup<NpToolkit2::TUS::Request::SetData>
	{
	public:

		TusSetDataCleanup(NpToolkit2::TUS::Request::SetData* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::TUS::Request::SetData* request = GetRequest();

			if ( request->data.buffer != NULL )
			{
				delete[] (UInt8*)request->data.buffer;
			}
		}
	};

	void TusGetDataManaged::CopyTo(NpToolkit2::TUS::Request::GetData &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		tusUser.CopyTo(destination.tusUser);
#else
		destination.isVirtualUser = tusUser.isVirtual;

		if (destination.isVirtualUser == true)
		{
			tusUser.virtualId.CopyTo(destination.virtualUserID);
		}
		else
		{
			destination.targetUser = tusUser.realId;
		}
#endif

		destination.slotId = slotId;

		destination.forCrossSave = forCrossSave;
		destination.retrieveStatusOnly = retrieveStatusOnly;
	}

	void TusDeleteDataManaged::CopyTo(NpToolkit2::TUS::Request::DeleteData &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		tusUser.CopyTo(destination.tusUser);
#else
		destination.isVirtualUser = tusUser.isVirtual;

		if (destination.isVirtualUser == true)
		{
			tusUser.virtualId.CopyTo(destination.virtualUserID);
		}
		else
		{
			destination.targetUser = tusUser.realId;
		}
#endif

		destination.numSlots = numSlots;

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		destination.slots = new SceNpTusSlotId[numSlots];

		for(int i = 0; i < numSlots; i++)
		{
			destination.slots[i] = slots[i];
		}
#else
		for(int i = 0; i < numSlots; i++)
		{
			destination.slotIds[i] = slots[i];
		}
#endif
	}

	class TusDeleteDataCleanup : public RequestCleanup<NpToolkit2::TUS::Request::DeleteData>
	{
	public:

		TusDeleteDataCleanup(NpToolkit2::TUS::Request::DeleteData* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
			NpToolkit2::TUS::Request::DeleteData* request = GetRequest();

			if (request->slots != NULL)
			{
				delete[]request->slots;
			}
#endif
		}
	};

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)

	void TusTryAndSetVariableManaged::CopyTo(NpToolkit2::TUS::Request::TryAndSetVariable &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		tusUser.CopyTo(destination.tusUser);

		varToUpdate.CopyTo(destination.varToUpdate);

		dataContention.CopyTo(destination.dataContention);

		destination.compareValue = compareValue;
		destination.compareOperator = compareOperator;

		destination.forCrossSave = forCrossSave;
	}

	void TusGetFriendsVariableManaged::CopyTo(NpToolkit2::TUS::Request::GetFriendsVariable &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.pageSize = pageSize;
		destination.slotId = slotId;		
		destination.sortingOrder = sortingOrder;
		destination.startIndex = startIndex;		
		destination.forCrossSave = forCrossSave;	
		destination.includeMeIfFound = includeMeIfFound;	
	}

	void TusGetUsersVariableManaged::CopyTo(NpToolkit2::TUS::Request::GetUsersVariable &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.maxUsersToObtain = maxUsersToObtain;
		destination.slotId = slotId;		
		destination.areVirtualUsers = areVirtualUsers;
		destination.forCrossSave = forCrossSave;		

		if ( areVirtualUsers == true )
		{
			destination.virtualUsersIds = new SceNpTusVirtualUserId[maxUsersToObtain];

			for(int i = 0; i < maxUsersToObtain; i++)
			{
				virtualUsersIds[i].CopyTo(destination.virtualUsersIds[i]);
			}
		}
		else
		{
			destination.realUsersIds = new SceNpAccountId[maxUsersToObtain];

			for(int i = 0; i < maxUsersToObtain; i++)
			{
				destination.realUsersIds[i] = realUsersIds[i];
			}
		}
	}

	class TusGetUsersVariableCleanup : public RequestCleanup<NpToolkit2::TUS::Request::GetUsersVariable>
	{
	public:

		TusGetUsersVariableCleanup(NpToolkit2::TUS::Request::GetUsersVariable* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::TUS::Request::GetUsersVariable* request = GetRequest();

			if (request->areVirtualUsers == true)
			{
				if (request->virtualUsersIds != NULL)
				{
					delete[]request->virtualUsersIds;
				}
			}
			else
			{
				if (request->realUsersIds != NULL)
				{
					delete[]request->realUsersIds;
				}
			}
		}
	};

	void TusGetUsersDataStatusManaged::CopyTo(NpToolkit2::TUS::Request::GetUsersDataStatus &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.maxUsersToObtain = maxUsersToObtain;
		destination.slotId = slotId;		
		destination.areVirtualUsers = areVirtualUsers;
		destination.forCrossSave = forCrossSave;		

		if ( areVirtualUsers == true )
		{
			destination.virtualUsersIds = new SceNpTusVirtualUserId[maxUsersToObtain];

			for(int i = 0; i < maxUsersToObtain; i++)
			{
				virtualUsersIds[i].CopyTo(destination.virtualUsersIds[i]);
			}
		}
		else
		{
			destination.realUsersIds = new SceNpAccountId[maxUsersToObtain];

			for(int i = 0; i < maxUsersToObtain; i++)
			{
				destination.realUsersIds[i] = realUsersIds[i];
			}
		}
	}

	class TusGetUsersDataStatusCleanup : public RequestCleanup<NpToolkit2::TUS::Request::GetUsersDataStatus>
	{
	public:

		TusGetUsersDataStatusCleanup(NpToolkit2::TUS::Request::GetUsersDataStatus* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::TUS::Request::GetUsersDataStatus* request = GetRequest();

			if (request->areVirtualUsers == true)
			{
				if (request->virtualUsersIds != NULL)
				{
					delete[]request->virtualUsersIds;
				}
			}
			else
			{
				if (request->realUsersIds != NULL)
				{
					delete[]request->realUsersIds;
				}
			}
		}
	};

	void TusGetFriendsDataStatusManaged::CopyTo(NpToolkit2::TUS::Request::GetFriendsDataStatus &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.pageSize = pageSize;
		destination.slotId = slotId;		
		destination.sortingOrder = sortingOrder;
		destination.startIndex = startIndex;
		destination.forCrossSave = forCrossSave;		
		destination.includeMeIfFound = includeMeIfFound;
	}
#endif

	int TUS::SetVariables(TusSetVariablesManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::TUS::Request::SetVariables* nptRequest = new NpToolkit2::TUS::Request::SetVariables();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::TUS::setVariables(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		TusSetVariablesCleanup* cleanup = new TusSetVariablesCleanup(nptRequest);
			
		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int TUS::GetVariables(TusGetVariablesManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTusVariablesResponse * nptResponse = new NptTusVariablesResponse();

		NpToolkit2::TUS::Request::GetVariables* nptRequest = new NpToolkit2::TUS::Request::GetVariables();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::TUS::getVariables(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		TusGetVariablesCleanup* cleanup = new TusGetVariablesCleanup(nptRequest);	
	
		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int TUS::AddToAndGetVariable(TusAddToAndGetVariableManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		//NptAtomicAddToAndGetVariableResponse * nptResponse = new NptAtomicAddToAndGetVariableResponse();

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
		NptTusVariablesResponse * nptResponse = new NptTusVariablesResponse();
#else
		NptAtomicAddToAndGetVariableResponse * nptResponse = new NptAtomicAddToAndGetVariableResponse();
#endif

		NpToolkit2::TUS::Request::AddToAndGetVariable nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::TUS::addToAndGetVariable(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int TUS::SetData(TusSetDataManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::TUS::Request::SetData* nptRequest = new NpToolkit2::TUS::Request::SetData();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::TUS::setData(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		TusSetDataCleanup* cleanup = new TusSetDataCleanup(nptRequest);
		
		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int TUS::GetData(TusGetDataManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTusDataResponse * nptResponse = new NptTusDataResponse();

		NpToolkit2::TUS::Request::GetData nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::TUS::getData(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int TUS::DeleteData(TusDeleteDataManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse * nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::TUS::Request::DeleteData* nptRequest = new NpToolkit2::TUS::Request::DeleteData();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::TUS::deleteData(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		TusDeleteDataCleanup* cleanup = new TusDeleteDataCleanup(nptRequest);
		
		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup );

		SUCCESS_RESULT(result);

		return ret;
	}


#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
	int TUS::TryAndSetVariable(TusTryAndSetVariableManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTusVariablesResponse * nptResponse = new NptTusVariablesResponse();

		NpToolkit2::TUS::Request::TryAndSetVariable nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::TUS::tryAndSetVariable(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int TUS::GetFriendsVariable(TusGetFriendsVariableManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTusFriendsVariablesResponse * nptResponse = new NptTusFriendsVariablesResponse();

		NpToolkit2::TUS::Request::GetFriendsVariable nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::TUS::getFriendsVariable(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int TUS::GetUsersVariable(TusGetUsersVariableManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTusVariablesResponse * nptResponse = new NptTusVariablesResponse();

		NpToolkit2::TUS::Request::GetUsersVariable* nptRequest = new NpToolkit2::TUS::Request::GetUsersVariable();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::TUS::getUsersVariable(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		TusGetUsersVariableCleanup* cleanup = new TusGetUsersVariableCleanup(nptRequest);

		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int TUS::GetUsersDataStatus(TusGetUsersDataStatusManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTusDataStatusesResponse * nptResponse = new NptTusDataStatusesResponse();

		NpToolkit2::TUS::Request::GetUsersDataStatus* nptRequest = new NpToolkit2::TUS::Request::GetUsersDataStatus();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::TUS::getUsersDataStatus(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
		
		TusGetUsersDataStatusCleanup* cleanup = new TusGetUsersDataStatusCleanup(nptRequest);
	
		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int TUS::GetFriendsDataStatus(TusGetFriendsDataStatusManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTusFriendsDataStatusesResponse * nptResponse = new NptTusFriendsDataStatusesResponse();

		NpToolkit2::TUS::Request::GetFriendsDataStatus nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::TUS::getFriendsDataStatus(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}
#endif

	// Marshal responses
	void TUS::MarshalTusVariables(NptTusVariablesResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::TusVariablesBegin);

		const NptTusVariables* tusVariables = response->get();

		buffer.WriteInt64(tusVariables->numVars);
		buffer.WriteBool(tusVariables->forCrossSave);

		for(int i = 0; i < tusVariables->numVars; i++)
		{
			if ( tusVariables->forCrossSave == true )
			{
#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
				WriteToBuffer(tusVariables->variablesForCrossSave[i], buffer);
#else
				WriteToBuffer(tusVariables->varsForCrossSave[i], buffer);
#endif
			}
			else
			{
#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
				WriteToBuffer(tusVariables->variables[i], buffer);
#else
				WriteToBuffer(tusVariables->vars[i], buffer);
#endif
			}
		}

		buffer.WriteMarker(BufferIntegrityChecks::TusVariablesEnd);

		SUCCESS_RESULT(result);
	}

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
	void TUS::MarshalTusFriendsVariable(NptTusFriendsVariablesResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::TusFriendsVariablesBegin);

		const NptTusFriendsVariables* tusFriendsVariables = response->get();

		buffer.WriteUInt32(tusFriendsVariables->totalFriends);

		const NptTusVariables& tusVariables = tusFriendsVariables->tusVariables;

		buffer.WriteInt64(tusVariables.numVars);
		buffer.WriteBool(tusVariables.forCrossSave);

		for(int i = 0; i < tusVariables.numVars; i++)
		{
			if ( tusVariables.forCrossSave == true )
			{
				WriteToBuffer(tusVariables.variablesForCrossSave[i], buffer);
			}
			else
			{
				WriteToBuffer(tusVariables.variables[i], buffer);
			}
		}

		buffer.WriteMarker(BufferIntegrityChecks::TusFriendsVariablesEnd);

		SUCCESS_RESULT(result);
	}

	void TUS::MarshalTusDataStatuses(NptTusDataStatusesResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptTusDataStatuses* tusDataStatuses = response->get();
		
		WriteToBuffer(*tusDataStatuses, buffer);

		SUCCESS_RESULT(result);
	}

	void TUS::MarshalTusFriendsDataStatusesResponse(NptTusFriendsDataStatusesResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::TusFriendsDataStatusesBegin);

		const NptTusFriendsDataStatuses* tusFriendsDataStatuses = response->get();

		buffer.WriteUInt32(tusFriendsDataStatuses->totalFriends);

		WriteToBuffer(tusFriendsDataStatuses->friendsStatuses, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::TusFriendsDataStatusesEnd);

		SUCCESS_RESULT(result);
	}

	void TUS::WriteToBuffer(const NptTusDataStatuses& tusDataStatuses, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::TusDataStatusesBegin);

		buffer.WriteUInt64(tusDataStatuses.numStatuses);
		buffer.WriteBool(tusDataStatuses.forCrossSave);

		if ( tusDataStatuses.forCrossSave == true )
		{
			for(int i = 0; i < tusDataStatuses.numStatuses; i++)
			{
				WriteToBuffer(tusDataStatuses.statusesForCrossSave[i], buffer);
			}
		}
		else
		{
			for(int i = 0; i < tusDataStatuses.numStatuses; i++)
			{
				WriteToBuffer(tusDataStatuses.statuses[i], buffer);
			}
		}

		buffer.WriteMarker(BufferIntegrityChecks::TusDataStatusesEnd);
	}

#endif

#if (SCE_ORBIS_SDK_VERSION < 0x05000000)
	// Need to read the data from the NptAtomicAddToAndGetVariableResponse but actually write it to the buffer as
	// though it was a NptTusVariablesResponse object instead. In SDK 5.0 NptAtomicAddToAndGetVariableResponse has been removed and replaced
	// witth NptTusVariablesResponse
	void TUS::MarshalAtomicAddToAndGetVariable(NptAtomicAddToAndGetVariableResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::TusVariablesBegin);

		const NptAtomicAddToAndGetVariable* tusAtomicAddToAndGetVariables = response->get();

		buffer.WriteInt64(1); // Atomic variables actually only contains 1 var
		buffer.WriteBool(tusAtomicAddToAndGetVariables->forCrossSave);

		if ( tusAtomicAddToAndGetVariables->forCrossSave == true )
		{
			WriteToBuffer(tusAtomicAddToAndGetVariables->varForCrossSave, buffer);
		}
		else
		{
			WriteToBuffer(tusAtomicAddToAndGetVariables->var, buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::TusVariablesEnd);

		SUCCESS_RESULT(result);
	}
#endif

	void TUS::MarshalTusData(NptTusDataResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::TusDataBegin);

		const NptTusData* tusData = response->get();

		if (response->getReturnCode() < 0)
		{
			buffer.WriteData(NULL, 0);
		}
		else 
		{
			buffer.WriteData((char*)tusData->data.buffer, tusData->data.bufferSize);
		}

		buffer.WriteBool(tusData->forCrossSave);

		if ( tusData->forCrossSave == true )
		{
#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
			WriteToBuffer(tusData->tusDataStatusForCrossSave, buffer);
#else
			WriteToBuffer(tusData->statusForCrossSave, buffer);
#endif
		}
		else
		{
#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
			WriteToBuffer(tusData->tusDataStatus, buffer);
#else
			WriteToBuffer(tusData->status, buffer);
#endif
		}

		buffer.WriteMarker(BufferIntegrityChecks::TusDataEnd);

		SUCCESS_RESULT(result);
	}

	// Write Methods
	void TUS::WriteToBuffer(const SceNpTusVariableA& sceNpTusVariable, MemoryBuffer& buffer)
	{
		// This must match the same as the SceNpTusVariableForCrossSave as both structures are nearly identical and the C# code will read
		// out the common data in a base class
		buffer.WriteBool((sceNpTusVariable.hasData != 0) ? true : false);
		Core::WriteToBuffer(sceNpTusVariable.lastChangedDate, buffer);   // SceRtcTick
		buffer.WriteInt64(sceNpTusVariable.variable);
		buffer.WriteInt64(sceNpTusVariable.oldVariable);
		Core::WriteToBuffer(sceNpTusVariable.ownerAccountId, buffer);
		Core::WriteToBuffer(sceNpTusVariable.lastChangedAuthorAccountId, buffer);

		// Specific to the SceNpScoreRankDataA structure
		Core::WriteToBuffer(sceNpTusVariable.ownerId, buffer);
		Core::WriteToBuffer(sceNpTusVariable.lastChangedAuthorId, buffer);
	}

	void TUS::WriteToBuffer(const SceNpTusVariableForCrossSave& sceNpTusVariableForCrossSave, MemoryBuffer& buffer)
	{
		// This must match the same as the SceNpTusVariableA as both structures are nearly identical and the C# code will read
		// out the common data in a base class

		buffer.WriteBool((sceNpTusVariableForCrossSave.hasData != 0) ? true : false);
		Core::WriteToBuffer(sceNpTusVariableForCrossSave.lastChangedDate, buffer);   // SceRtcTick
		buffer.WriteInt64(sceNpTusVariableForCrossSave.variable);
		buffer.WriteInt64(sceNpTusVariableForCrossSave.oldVariable);
		Core::WriteToBuffer(sceNpTusVariableForCrossSave.ownerAccountId, buffer);
		Core::WriteToBuffer(sceNpTusVariableForCrossSave.lastChangedAuthorAccountId, buffer);

		// Specific to the SceNpScoreRankDataA structure
		Core::WriteToBuffer(sceNpTusVariableForCrossSave.ownerId, buffer);
		Core::WriteToBuffer(sceNpTusVariableForCrossSave.lastChangedAuthorId, buffer);
	}

#if (SCE_ORBIS_SDK_VERSION >= 0x05000000)
	void TUS::WriteToBuffer(const NpToolkit2::TUS::TusDataStatus& tusDataStatus, MemoryBuffer& buffer)
	{
		buffer.WriteBool(tusDataStatus.hasData);
		Core::WriteToBuffer(tusDataStatus.lastChangedDate, buffer);   // SceRtcTick
		//buffer.WriteData((char*)tusDataStatus.supplementaryInfo, tusDataStatus.supplementaryInfoSize);
		buffer.WriteData((char*)tusDataStatus.supplementaryInfo, 0);

		Core::WriteToBuffer(tusDataStatus.owner, buffer);
		Core::WriteToBuffer(tusDataStatus.lastChangedBy, buffer);
	}

	void TUS::WriteToBuffer(const NpToolkit2::TUS::TusDataStatusForCrossSave& tusDataStatusForCrossSave, MemoryBuffer& buffer)
	{
		buffer.WriteBool(tusDataStatusForCrossSave.hasData);
		Core::WriteToBuffer(tusDataStatusForCrossSave.lastChangedDate, buffer);   // SceRtcTick
		//buffer.WriteData((char*)tusDataStatusForCrossSave.supplementaryInfo, tusDataStatusForCrossSave.supplementaryInfoSize);
		buffer.WriteData((char*)tusDataStatusForCrossSave.supplementaryInfo, 0);

		Core::WriteToBuffer(tusDataStatusForCrossSave.ownerAccountId, buffer);
		Core::WriteToBuffer(tusDataStatusForCrossSave.lastChangedByAccountId, buffer);
		Core::WriteToBuffer(tusDataStatusForCrossSave.ownerNpId, buffer);
		Core::WriteToBuffer(tusDataStatusForCrossSave.lastChangedByNpId, buffer);
	}
#else
	void TUS::WriteToBuffer(const SceNpTusDataStatusA& sceNpTusDataStatus, MemoryBuffer& buffer)
	{
		buffer.WriteBool((sceNpTusDataStatus.hasData != 0) ? true : false);
		Core::WriteToBuffer(sceNpTusDataStatus.lastChangedDate, buffer);   // SceRtcTick

		// Write dummy supplementaryInfo as this only exists in SDK 5.0
		buffer.WriteData(NULL, 0);

		// Write the owner online id
		buffer.WriteMarker(BufferIntegrityChecks::OnlineUserBegin);

		buffer.WriteUInt64(sceNpTusDataStatus.ownerAccountId);
		Core::WriteToBuffer(sceNpTusDataStatus.ownerId, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::OnlineUserEnd);

		// Write the last changed online id
		buffer.WriteMarker(BufferIntegrityChecks::OnlineUserBegin);

		buffer.WriteUInt64(sceNpTusDataStatus.lastChangedAuthorAccountId);
		Core::WriteToBuffer(sceNpTusDataStatus.lastChangedAuthorId, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::OnlineUserEnd);
	}

	void TUS::WriteToBuffer(const SceNpTusDataStatusForCrossSave& sceNpTusDataStatusForCrossSave, MemoryBuffer& buffer)
	{
		// This must match the same as the SceNpTusDataStatusA as both structures are nearly identical and the C# code will read
		// out the common data in a base class

		buffer.WriteBool((sceNpTusDataStatusForCrossSave.hasData != 0) ? true : false);
		Core::WriteToBuffer(sceNpTusDataStatusForCrossSave.lastChangedDate, buffer);   // SceRtcTick

		buffer.WriteData((char*)sceNpTusDataStatusForCrossSave.data, sceNpTusDataStatusForCrossSave.dataSize);
		buffer.WriteData((char*)sceNpTusDataStatusForCrossSave.info.data, sceNpTusDataStatusForCrossSave.info.infoSize);

		Core::WriteToBuffer(sceNpTusDataStatusForCrossSave.ownerAccountId, buffer);
		Core::WriteToBuffer(sceNpTusDataStatusForCrossSave.lastChangedAuthorAccountId, buffer);

		// Specific to the SceNpTusDataStatusA structure
		Core::WriteToBuffer(sceNpTusDataStatusForCrossSave.ownerId, buffer);
		Core::WriteToBuffer(sceNpTusDataStatusForCrossSave.lastChangedAuthorId, buffer);
	}
#endif

}
