#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	struct TerminateServiceManaged : public RequestBaseManaged
	{
		NpToolkit2::Core::ServiceType service;

		void CopyTo(NpToolkit2::Core::Request::TerminateService &destination);
	};

	class Core
	{
	public:

		typedef NpToolkit2::Core::Empty NptEmpty;
		typedef NpToolkit2::Core::Response<NpToolkit2::Core::Empty> NptEmptyResponse;

		static int TerminateService(TerminateServiceManaged* managedRequest, APIResult* result);

		static void WriteToBuffer(const NpToolkit2::Core::OnlineUser& onLineUser, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpOnlineId& onLineId, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpCountryCode& countryCode, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpTitleId& titleId, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpLanguageCode& languageCode, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceRtcTick& ticks, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpAccountId& accountId, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpId& npId, MemoryBuffer& buffer);
	
		// Notification Copies
		static void CopyServerError(NpToolkit2::Core::ServerError& destination, const NpToolkit2::Core::ServerError& source);
		static void CopyResponseBase(NpToolkit2::Core::ResponseBase& destination, NpToolkit2::Core::ResponseBase& source);

		// Marshal methods
		static void MarshalEmpty(NptEmptyResponse* emptyResponse, MemoryBuffer& buffer, APIResult* result);
	};

	class PNGWriter
	{
	public:
		struct PNG
		{
			char png[4];
			char crlfczlf[4];
		};

		struct IHDR
		{
			char ihdr[4];
			int ihdrlen;
			int width;
			int height;
			char bitDepth;
			char colorType;
			char compressionMethod;
			char filterMethod;
			char interlaceMethod;
		};

		static void WriteToBuffer(const void* iconData, Int32 size,  MemoryBuffer& buffer);

	private:
		static void SwapBytes(short* val);
		static void SwapEndian(int* val);
	};
}





