#ifndef _MAIN_H
#define _MAIN_H

#include "../Includes/PluginCommonIncludes.h"
#include "Init.h"

namespace NPT
{
	
	class Main
	{
	public:

		class ValidationChecks
		{
		public:
			UInt32 expectedNumFunctionTypes;
		};

	private:
	#if defined(GLOBAL_EVENT_QUEUE)
		static UnityPlugin::PS4SystemEventManager s_SystemEventManager;
	#endif
		static bool s_Initialised;

		static IPluginUnity* s_IUnity;
		static IPluginSceAppParams* s_ISceAppParams;
		static IPluginSceNpParams* s_ISceNpParams;

	public:

		static bool ValidateToolkit(ValidationChecks& validate, APIResult* result);

		static void InitializeToolkit(Init::InitToolkit& init, Init::InitResult& initResult, ManagedEventCallback pendingResultsCallback, ManagedEventCallback npRequestEventCallback, APIResult* result);
		static void Update();
		static void Shutdown();

		static void LoadModules();
		static void UnloadModules();

		static void HandleAppLaunchEvent(char* args, UInt32 size);
	private:

		static void SetupRuntimeInterfaces();

		static void NpToolkitCallback(NpToolkit2::Core::CallbackEvent* event);
	};
}

#endif	//_MAIN_H




