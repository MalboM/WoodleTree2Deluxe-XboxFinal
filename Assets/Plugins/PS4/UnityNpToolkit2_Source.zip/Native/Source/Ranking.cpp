#include <stdio.h>

#include "Ranking.h"

namespace NPT
{
	DO_EXPORT( int, PrxSetScore ) (SetScoreManaged* managedRequest, APIResult* result)
	{
		return Ranking::SetScore(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetRangeOfRanks ) (GetRangeOfRanksManaged* managedRequest, APIResult* result)
	{
		return Ranking::GetRangeOfRanks(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetFriendsRanks ) (GetFriendsRanksManaged* managedRequest, APIResult* result)
	{
		return Ranking::GetFriendsRanks(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetUsersRanks ) (GetUsersRanksManaged* managedRequest, APIResult* result)
	{
		return Ranking::GetUsersRanks(managedRequest, result);
	}

	DO_EXPORT( int, PrxSetGameData ) (SetGameDataManaged* managedRequest, APIResult* result)
	{
		return Ranking::SetGameData(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetGameData ) (GetGameDataManaged* managedRequest, APIResult* result)
	{
		return Ranking::GetGameData(managedRequest, result);
	}

	void SetScoreManaged::CopyTo(NpToolkit2::Ranking::Request::SetScore &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.score = score;
		strncpy(destination.comment.utf8Comment, utf8Comment, SCE_NP_SCORE_COMMENT_MAXLEN+1);

		memcpy(destination.gameInfo.data, data, SCE_NP_SCORE_GAMEINFO_MAXSIZE);
		destination.gameInfo.infoSize = dataLength;

		destination.boardId = boardId;
		destination.pcId = pcId;
	}

	void GetRangeOfRanksManaged::CopyTo(NpToolkit2::Ranking::Request::GetRangeOfRanks &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.boardId = boardId;				                                         
		destination.startRank = startRank;		
		destination.range = range;				
		destination.isCrossSaveInformation = isCrossSaveInformation;                      
	}

	void GetFriendsRanksManaged::CopyTo(NpToolkit2::Ranking::Request::GetFriendsRanks &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.boardId = boardId;				                                         
		destination.startRank = startRank;		
		destination.friendsWithPcId = friendsWithPcId;				
		destination.isCrossSaveInformation = isCrossSaveInformation;       
		destination.addCallingUserRank = addCallingUserRank;      
	}

	void GetUsersRanksManaged::CopyTo(NpToolkit2::Ranking::Request::GetUsersRanks &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.users = new SceNpScoreAccountIdPcId[numUsers];

		for(int i = 0; i < numUsers; i++)
		{
			destination.users[i].accountId = users[i].accountId;
			destination.users[i].pcId = users[i].pcId;
		}
		
		destination.numUsers = numUsers;
		destination.boardId = boardId;				                                         				
		destination.isCrossSaveInformation = isCrossSaveInformation;       
		destination.ignorePcIds = ignorePcIds;      
	}

	class GetUsersRanksCleanup : public RequestCleanup<NpToolkit2::Ranking::Request::GetUsersRanks>
	{
	public:

		GetUsersRanksCleanup(NpToolkit2::Ranking::Request::GetUsersRanks* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::Ranking::Request::GetUsersRanks* request = GetRequest();

			delete[] request->users;
		}
	};

	void SetGameDataManaged::CopyTo(NpToolkit2::Ranking::Request::SetGameData &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.boardId = boardId;
		destination.idOfPrevChunk = idOfPrevChunk;
		destination.score = score;
		destination.totalSize = totalSize;
		destination.chunkDataSize = chunkDataSize;
		destination.pcId = pcId;

		UInt8* startData = (UInt8*)data;
		startData += byteOffset;

		// Now fixup the chunkData
		// This need to be done as the GC might move the managed chunkData ptr after this function returns.
		// The SetGameData doesn't take a deep copy of this data, so it needs to remain allocated during the request call.
		UInt8* data = new UInt8[chunkDataSize];
		memcpy(data, startData, chunkDataSize); 

		destination.chunkData = data;
	}

	class SetGameDataCleanup : public RequestCleanup<NpToolkit2::Ranking::Request::SetGameData>
	{
	public:

		SetGameDataCleanup(NpToolkit2::Ranking::Request::SetGameData* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::Ranking::Request::SetGameData* request = GetRequest();

			delete[] (UInt8*)request->chunkData;
		}
	};

	void GetGameDataManaged::CopyTo(NpToolkit2::Ranking::Request::GetGameData &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.boardId = boardId;
		destination.idOfPrevChunk = idOfPrevChunk;
		destination.accountId = accountId;
		destination.chunkToRcvDataSize = chunkToRcvDataSize;
		destination.pcId = pcId;

		UInt8* data = new UInt8[chunkToRcvDataSize];

		destination.chunkToRcvData = data;                                            
	}

	class GetGameDataCleanup : public RequestCleanup<NpToolkit2::Ranking::Request::GetGameData>
	{
	public:

		GetGameDataCleanup(NpToolkit2::Ranking::Request::GetGameData* requestPtr) : RequestCleanup(requestPtr) { }

		void Cleanup()
		{
			NpToolkit2::Ranking::Request::GetGameData* request = GetRequest();

			delete[] (UInt8*)request->chunkToRcvData;
		}
	};

	int Ranking::SetScore(SetScoreManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTempRankResponse* nptResponse = new NptTempRankResponse();

		NpToolkit2::Ranking::Request::SetScore nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Ranking::setScore(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Ranking::GetRangeOfRanks(GetRangeOfRanksManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptRangeOfRanksResponse* nptResponse = new NptRangeOfRanksResponse();

		NpToolkit2::Ranking::Request::GetRangeOfRanks nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Ranking::getRangeOfRanks(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Ranking::GetFriendsRanks(GetFriendsRanksManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptFriendsRanksResponse* nptResponse = new NptFriendsRanksResponse();

		NpToolkit2::Ranking::Request::GetFriendsRanks nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Ranking::getFriendsRanks(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Ranking::GetUsersRanks(GetUsersRanksManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptUsersRanksResponse* nptResponse = new NptUsersRanksResponse();

		NpToolkit2::Ranking::Request::GetUsersRanks* nptRequest = new NpToolkit2::Ranking::Request::GetUsersRanks();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::Ranking::getUsersRanks(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		GetUsersRanksCleanup* cleanup = new GetUsersRanksCleanup(nptRequest);
	
		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Ranking::SetGameData(SetGameDataManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptSetGameDataResultResponse* nptResponse = new NptSetGameDataResultResponse();

		NpToolkit2::Ranking::Request::SetGameData* nptRequest = new NpToolkit2::Ranking::Request::SetGameData();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::Ranking::setGameData(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		SetGameDataCleanup* cleanup = new SetGameDataCleanup(nptRequest);
	
		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Ranking::GetGameData(GetGameDataManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptGetGameDataResultResponse* nptResponse = new NptGetGameDataResultResponse();

		NpToolkit2::Ranking::Request::GetGameData* nptRequest = new NpToolkit2::Ranking::Request::GetGameData();

		managedRequest->CopyTo(*nptRequest);

		int ret = NpToolkit2::Ranking::getGameData(*nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		GetGameDataCleanup* cleanup = new GetGameDataCleanup(nptRequest);
		
		ResponseMap::Add(nptResponse, *nptRequest, ret, cleanup);

		SUCCESS_RESULT(result);

		return ret;
	}


	// Marshal methods
	void Ranking::MarshalTempRank(NptTempRankResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptTempRank* tempRank = response->get();

		buffer.WriteMarker(BufferIntegrityChecks::TempRankBegin);
		
		buffer.WriteInt32(tempRank->tempRank);
		
		buffer.WriteMarker(BufferIntegrityChecks::TempRankEnd);

		SUCCESS_RESULT(result);
	}

	void Ranking::MarshalRangeOfRanks(NptRangeOfRanksResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptRangeOfRanks* rangeOfRanks = response->get();

		buffer.WriteMarker(BufferIntegrityChecks::RangeOfRanksBegin);

		buffer.WriteBool(rangeOfRanks->isCrossSaveInformation);
		buffer.WriteUInt64(rangeOfRanks->range);

		for(int i = 0; i < rangeOfRanks->range; i++ )
		{
			if ( rangeOfRanks->isCrossSaveInformation == true )
			{
				WriteToBuffer(rangeOfRanks->crossSaveRankData[i], buffer);
			}
			else
			{
				WriteToBuffer(rangeOfRanks->rankData[i], buffer);
			}

			buffer.WriteString(rangeOfRanks->comment[i].utf8Comment); 
			buffer.WriteData((char*)rangeOfRanks->gameInfo[i].data, rangeOfRanks->gameInfo[i].infoSize); 
		}

		buffer.WriteUInt64(rangeOfRanks->numValidEntries);

		Core::WriteToBuffer(rangeOfRanks->updateTime, buffer);

		buffer.WriteUInt32(rangeOfRanks->totalEntriesOnBoard);
		buffer.WriteUInt32(rangeOfRanks->boardId);
		buffer.WriteInt32(rangeOfRanks->startRank);

		buffer.WriteMarker(BufferIntegrityChecks::RangeOfRanksEnd);                                                                

		SUCCESS_RESULT(result);
	}

	void Ranking::MarshalFriendsRanks(NptFriendsRanksResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptFriendsRanks* friendsRanks = response->get();

		buffer.WriteMarker(BufferIntegrityChecks::FriendsRanksBegin);

         buffer.WriteBool(friendsRanks->isCrossSaveInformation);

        if (response->getReturnCode() < 0 )
        {
            buffer.WriteUInt64(0); // Number friends 0. When an error occurs friendsRanks->numValidFriends contains the error code.
        }
        else
        {
		    buffer.WriteUInt64(friendsRanks->numValidFriends);

		    for(int i = 0; i < friendsRanks->numValidFriends; i++ )
		    {
			    if ( friendsRanks->isCrossSaveInformation == true )
			    {
				    WriteToBuffer(friendsRanks->crossSaveRankData[i], buffer);
			    }
			    else
			    {
				    WriteToBuffer(friendsRanks->rankData[i], buffer);
			    }

			    buffer.WriteString(friendsRanks->comment[i].utf8Comment); 
			    buffer.WriteData((char*)friendsRanks->gameInfo[i].data, friendsRanks->gameInfo[i].infoSize); 
		    }
        }

        Core::WriteToBuffer(friendsRanks->updateTime, buffer);

		buffer.WriteUInt32(friendsRanks->boardId);
		buffer.WriteUInt32(friendsRanks->totalEntriesOnBoard);
		buffer.WriteUInt32(friendsRanks->totalFriendsOnBoard);
		buffer.WriteInt32(friendsRanks->friendsWithPcId);

		buffer.WriteMarker(BufferIntegrityChecks::FriendsRanksEnd);

		SUCCESS_RESULT(result);
	}

	void Ranking::MarshalUsersRanks(NptUsersRanksResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptUsersRanks* usersRanks = response->get();

		buffer.WriteMarker(BufferIntegrityChecks::UsersRanksBegin);

		buffer.WriteBool(usersRanks->isCrossSaveInformation);

		if (response->getReturnCode() < 0)
		{
			buffer.WriteUInt64(0); // Number Users 0. When an error occurs numUsers contains bad data.
			buffer.WriteUInt64(0); // Number Valid Users 0. When an error occurs numValidUsers contains bad data.
		}
		else
		{
			buffer.WriteUInt64(usersRanks->numUsers);
			buffer.WriteUInt64(usersRanks->numValidUsers);

			for (int i = 0; i < usersRanks->numUsers; i++)
			{
				bool writeOtherData = true;
				if (usersRanks->isCrossSaveInformation == true)
				{
					WriteToBuffer(usersRanks->usersForCrossSave[i], buffer);
					writeOtherData = usersRanks->usersForCrossSave[i].hasData;
				}
				else
				{
					WriteToBuffer(usersRanks->users[i], buffer);
					writeOtherData = usersRanks->users[i].hasData;
				}

				if (writeOtherData == true)
				{
					buffer.WriteString(usersRanks->comment[i].utf8Comment);
					buffer.WriteData((char*)usersRanks->gameInfo[i].data, usersRanks->gameInfo[i].infoSize);
				}
			}
		}

		Core::WriteToBuffer(usersRanks->updateTime, buffer);

		buffer.WriteUInt32(usersRanks->boardId);
		buffer.WriteUInt32(usersRanks->totalEntriesOnBoard);

		buffer.WriteMarker(BufferIntegrityChecks::UsersRanksEnd);

		SUCCESS_RESULT(result);
	}

	void Ranking::MarshalSetGameDataResult(NptSetGameDataResultResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptSetGameDataResult* setGameData = response->get();

		buffer.WriteMarker(BufferIntegrityChecks::SetGameDataBegin);

		buffer.WriteInt32(setGameData->chunkId);

		buffer.WriteMarker(BufferIntegrityChecks::SetGameDataEnd);

		SUCCESS_RESULT(result);
	}

	void Ranking::MarshalGetGameDataResult(NptGetGameDataResultResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptGetGameDataResult* getGameData = response->get();

		buffer.WriteMarker(BufferIntegrityChecks::GetGameDataBegin);

		buffer.WriteUInt64(getGameData->totalSize);
		buffer.WriteUInt64(getGameData->rcvDataSize);
		buffer.WriteUInt64(getGameData->rcvDataValidSize);
		buffer.WriteInt32(getGameData->chunkId);
		buffer.WriteData((char*)getGameData->rcvData, getGameData->rcvDataSize);

		buffer.WriteMarker(BufferIntegrityChecks::GetGameDataEnd);

		SUCCESS_RESULT(result);
	}

	void Ranking::WriteToBuffer(const SceNpScorePlayerRankDataA& sceNpScorePlayerRankData, MemoryBuffer& buffer)
	{
		buffer.WriteBool((sceNpScorePlayerRankData.hasData != 0) ? true : false);

		if ( sceNpScorePlayerRankData.hasData != 0 )
		{
			WriteToBuffer(sceNpScorePlayerRankData.rankData, buffer);
		}
	}

	void Ranking::WriteToBuffer(const SceNpScorePlayerRankDataForCrossSave& sceNpScorePlayerRankDataForCrossSave, MemoryBuffer& buffer)
	{
		buffer.WriteBool((sceNpScorePlayerRankDataForCrossSave.hasData != 0) ? true : false);

		if ( sceNpScorePlayerRankDataForCrossSave.hasData != 0 )
		{
			WriteToBuffer(sceNpScorePlayerRankDataForCrossSave.rankData, buffer);
		}
	}

	void Ranking::WriteToBuffer(const SceNpScoreRankDataA& sceNpScoreRankData, MemoryBuffer& buffer)
	{
		// This must match the same as the SceNpScoreRankDataForCrossSave as both structures are nearly identical and the C# code will read
		// out the common data in a base class
		buffer.WriteInt32(sceNpScoreRankData.pcId);
		buffer.WriteUInt32(sceNpScoreRankData.serialRank);
		buffer.WriteUInt32(sceNpScoreRankData.rank);
		buffer.WriteUInt32(sceNpScoreRankData.highestRank);

		buffer.WriteBool((sceNpScoreRankData.hasGameData != 0) ? true : false);

		buffer.WriteInt64(sceNpScoreRankData.scoreValue);

		Core::WriteToBuffer(sceNpScoreRankData.recordDate, buffer);
		
		Core::WriteToBuffer(sceNpScoreRankData.accountId, buffer);

		// Specific to the SceNpScoreRankDataA structure
		Core::WriteToBuffer(sceNpScoreRankData.onlineId, buffer);
	}

	void Ranking::WriteToBuffer(const SceNpScoreRankDataForCrossSave& sceNpScoreRankDataForCrossSave, MemoryBuffer& buffer)
	{
		// This must match the same as the SceNpScoreRankDataA as both structures are nearly identical and the C# code will read
		// out the common data in a base class
		buffer.WriteInt32(sceNpScoreRankDataForCrossSave.pcId);
		buffer.WriteUInt32(sceNpScoreRankDataForCrossSave.serialRank);
		buffer.WriteUInt32(sceNpScoreRankDataForCrossSave.rank);
		buffer.WriteUInt32(sceNpScoreRankDataForCrossSave.highestRank);

		buffer.WriteBool((sceNpScoreRankDataForCrossSave.hasGameData != 0) ? true : false);

		buffer.WriteInt64(sceNpScoreRankDataForCrossSave.scoreValue);

		Core::WriteToBuffer(sceNpScoreRankDataForCrossSave.recordDate, buffer);
		
		Core::WriteToBuffer(sceNpScoreRankDataForCrossSave.accountId, buffer);

		// Specific to the SceNpScoreRankDataForCrossSave structure
		Core::WriteToBuffer(sceNpScoreRankDataForCrossSave.npId, buffer);
	}
}
