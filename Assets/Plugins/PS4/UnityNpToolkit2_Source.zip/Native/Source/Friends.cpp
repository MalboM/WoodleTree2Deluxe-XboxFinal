#include <stdio.h>

#include "Friends.h"

#include <rtc.h>
#include <libsysmodule.h>

#include "Core.h"
#include "Profile.h"
#include "Presence.h"

namespace NPT
{
	DO_EXPORT( int, PrxGetFriends ) (GetFriendsManaged* managedRequest, APIResult* result)
	{
		return Friends::GetFriends(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetFriendsOfFriends ) (GetFriendsOfFriendsManaged* managedRequest, APIResult* result)
	{
		return Friends::GetFriendsOfFriends(managedRequest, result);
	}

	/// Get Blocked Users
	DO_EXPORT( int, PrxGetBlockedUsers ) (GetBlockedUsersManaged* managedRequest, APIResult* result)
	{
		return Friends::GetBlockedUsers(managedRequest, result);
	}

	/// Display Friend Request Dialog
	DO_EXPORT( int, PrxDisplayFriendRequestDialog ) (DisplayFriendRequestDialogManaged* managedRequest, APIResult* result)
	{
		return Friends::DisplayFriendRequestDialog(managedRequest, result);
	}

	DO_EXPORT( int, PrxDisplayBlockUserDialog ) (DisplayBlockUserDialogManaged* managedRequest, APIResult* result)
	{
		return Friends::DisplayBlockUserDialog(managedRequest, result);
	}

	//
	//
	// Friends Request
	//
	//
	void GetFriendsManaged::CopyTo(NpToolkit2::Friend::Request::GetFriends &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.mode = mode; ///< The specific mode for the request
		destination.limit = limit; ///< The number of friends to be requested in a single call. If set to 0, all friends will be retrieved and offset will be ignored as well
		destination.offset = offset; ///< The offset into the list of the users friends at which to start retrieving friends
	}

	int Friends::GetFriends(GetFriendsManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptFriendsResponse* nptResponse = new NptFriendsResponse();

		NpToolkit2::Friend::Request::GetFriends nptRequest;

		managedRequest->CopyTo(nptRequest);

		// If the request (synchronous or asynchronous) couldn't be sent to the ToolkitNp2 thread then an error code is returned.
		// If the operation is synchronous, the function provides the return code (see possible values in the table).
		// If the operation is asynchronous, the function provides the request Id, in case the request needs to be aborted. 
		//       Once the request completes, the application will be notified via the ToolkitNp2 callbacks. 
		//       The CallbackEvent argument of the callbacks will contain the return code (see possible values in the table), 
		//       the request Id returned by the function when it was called, the id of the user who performed the request, 
		//       friends as the ServiceType, friendsGetFriends as the FunctionType and a pointer to the response object 
		//       supplied to this function via the res parameter.

		int ret = NpToolkit2::Friend::getFriends(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	//
	//
	// Friends of Friends Request
	//
	//

	void GetFriendsOfFriendsManaged::CopyTo(NpToolkit2::Friend::Request::GetFriendsOfFriends &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		if ( numAccountIds > NpToolkit2::Friend::Request::GetFriendsOfFriends::MAX_ACCOUNT_IDS )
		{
			numAccountIds = NpToolkit2::Friend::Request::GetFriendsOfFriends::MAX_ACCOUNT_IDS;
		}

		destination.numAccountIds = numAccountIds;

		for(int i = 0;i < numAccountIds; i++)
		{
			destination.accountIds[i] = accountIds[i];
		}
	}

	int Friends::GetFriendsOfFriends(GetFriendsOfFriendsManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptFriendsOfFriendsResponse* nptResponse = new NptFriendsOfFriendsResponse();

		NpToolkit2::Friend::Request::GetFriendsOfFriends nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Friend::getFriendsOfFriends(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	

	/// Blocked Users
	void GetBlockedUsersManaged::CopyTo(NpToolkit2::Friend::Request::GetBlockedUsers &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.mode = mode;
		destination.limit = limit;
		destination.offset = offset;
	}

	int Friends::GetBlockedUsers(GetBlockedUsersManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptBlockedUsersResponse* nptResponse = new NptBlockedUsersResponse();

		NpToolkit2::Friend::Request::GetBlockedUsers nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Friend::getBlockedUsers(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	void DisplayFriendRequestDialogManaged::CopyTo(NpToolkit2::Friend::Request::DisplayFriendRequestDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.targetUser = targetUser;
	}

	int Friends::DisplayFriendRequestDialog(DisplayFriendRequestDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Friend::Request::DisplayFriendRequestDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Friend::displayFriendRequestDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	// Display Block User Dialog
	void DisplayBlockUserDialogManaged::CopyTo(NpToolkit2::Friend::Request::DisplayBlockUserDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.targetUser = targetUser;
	}

	int Friends::DisplayBlockUserDialog(DisplayBlockUserDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::Friend::Request::DisplayBlockUserDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Friend::displayBlockUserDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	void Friends::WriteToBuffer(NpToolkit2::Friend::Friend& npFriend, MemoryBuffer& buffer)
	{
		buffer.WriteMarker(BufferIntegrityChecks::FriendBegin);

		Profile::WriteToBuffer(npFriend.profile, buffer);
		Presence::WriteToBuffer(npFriend.presence, buffer);

		buffer.WriteMarker(BufferIntegrityChecks::FriendEnd);
	}

	void Friends::MarshalFriends(NptFriendsResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::FriendsBegin);

		const NptFriends* friends = response->get();

		UInt32 numFriends = friends->numFriends;

		buffer.WriteUInt32((UInt32)numFriends);

		for(int i = 0; i < numFriends; i++)
		{
			WriteToBuffer(friends->friends[i], buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::FriendsEnd);

		SUCCESS_RESULT(result);
	}

	/// Get Friends of Friends Response
	void Friends::MarshalFriendsOfFriends(NptFriendsOfFriendsResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::FriendsOfFriendsBegin);

		const NptFriendsOfFriends* friendsOfFriends = response->get();

		int numFriendsOfFriends = friendsOfFriends->numFriendsOfFriends;

		buffer.WriteUInt32((UInt32)numFriendsOfFriends);

		for(int i = 0; i < numFriendsOfFriends; i++)
		{
			NpToolkit2::Friend::FriendsOfFriend* friendsOfFriend = &friendsOfFriends->friendsOfFriends[i];

			Core::WriteToBuffer(friendsOfFriend->originalFriend, buffer);
			buffer.WriteUInt32((UInt32)friendsOfFriend->numUsers);

			for(int u = 0; u < friendsOfFriend->numUsers; u++)
			{
				Core::WriteToBuffer(friendsOfFriend->users[u], buffer);
			}
		}

		buffer.WriteMarker(BufferIntegrityChecks::FriendsOfFriendsEnd);

		SUCCESS_RESULT(result);
	}
	
	void Friends::MarshalBlockedUsers(NptBlockedUsersResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::BlockedUsersBegin);

		const NptBlockedUsers* blockedUsers = response->get();

		int numUsers = blockedUsers->numUsers;

		buffer.WriteUInt32((UInt32)numUsers);

		for(int i = 0; i < numUsers; i++)
		{
			Core::WriteToBuffer(blockedUsers->users[i], buffer);
		}
	
		buffer.WriteMarker(BufferIntegrityChecks::BlockedUsersEnd);

		SUCCESS_RESULT(result);
	}


	void Friends::MarshalFriendlistUpdate(NptFriendlistUpdateResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		buffer.WriteMarker(BufferIntegrityChecks::FriendListUpdateBegin);

		const NptFriendlistUpdate* friendListUpdate = response->get();

		Core::WriteToBuffer(friendListUpdate->localUpdatedUser, buffer);
		Core::WriteToBuffer(friendListUpdate->remoteUser, buffer);

		buffer.WriteInt32(friendListUpdate->userId);
		buffer.WriteInt32((Int32)friendListUpdate->eventType);

		buffer.WriteMarker(BufferIntegrityChecks::FriendListUpdateEnd);

		SUCCESS_RESULT(result);
	}

	void Friends::MarshalBlocklistUpdate(NptBlocklistUpdateResponse* response, MemoryBuffer& buffer, APIResult* result)
	{		
		buffer.WriteMarker(BufferIntegrityChecks::BlocklistUpdateBegin);

		const NptBlocklistUpdate* blocklistUpdate = response->get();

		Core::WriteToBuffer(blocklistUpdate->localUpdatedUser, buffer);
		buffer.WriteInt32(blocklistUpdate->userId);

		buffer.WriteMarker(BufferIntegrityChecks::BlocklistUpdateEnd);

		SUCCESS_RESULT(result);
	}

}
