#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	struct SceNpClientIdManaged
	{
		void CopyTo(SceNpClientId &destination);

		char id[SCE_NP_CLIENT_ID_MAX_LEN + 1];
	};

	struct SceNpClientSecretManaged
	{
		void CopyTo(SceNpClientSecret &destination);

		char secret[SCE_NP_CLIENT_SECRET_MAX_LEN + 1];
	};

	class GetAuthCodeManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::Auth::Request::GetAuthCode &destination);

		SceNpClientIdManaged clientId;	
		char scope[NpToolkit2::Auth::Request::GetAuthCode::MAX_SIZE_SCOPE + 1];	
	};	

	class GetIdTokenManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::Auth::Request::GetIdToken &destination);

		SceNpClientIdManaged clientId;
		SceNpClientSecretManaged clientSecret;
		char scope[NpToolkit2::Auth::Request::GetIdToken::MAX_SIZE_SCOPE + 1];
	};	

	class Auth
	{
	public:

		typedef NpToolkit2::Auth::AuthCode NptAuthCode;
		typedef NpToolkit2::Core::Response<NptAuthCode> NptAuthCodeResponse;

		typedef NpToolkit2::Auth::IdToken NptIdToken;
		typedef NpToolkit2::Core::Response<NptIdToken> NptIdTokenResponse;

		//Requests
		static int GetAuthCode(GetAuthCodeManaged* managedRequest, APIResult* result);
		static int GetIdToken(GetIdTokenManaged* managedRequest, APIResult* result);

		// Marshal methods
		static void MarshalAuthCode(NptAuthCodeResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalIdToken(NptIdTokenResponse* response, MemoryBuffer& buffer, APIResult* result);
	};
}





