
#include "Auth.h"

#include "Core.h"

namespace NPT
{
	DO_EXPORT( int, PrxGetAuthCode ) (GetAuthCodeManaged* managedRequest, APIResult* result)
	{
		return Auth::GetAuthCode(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetIdToken ) (GetIdTokenManaged* managedRequest, APIResult* result)
	{
		return Auth::GetIdToken(managedRequest, result);
	}

	void SceNpClientIdManaged::CopyTo(SceNpClientId &destination)
	{
		(void)strcpy_s(destination.id, SCE_NP_CLIENT_ID_MAX_LEN + 1, id);
	}

	void SceNpClientSecretManaged::CopyTo(SceNpClientSecret &destination)
	{
		strcpy_s(destination.secret, SCE_NP_CLIENT_SECRET_MAX_LEN + 1, secret);
	}

	void GetAuthCodeManaged::CopyTo(NpToolkit2::Auth::Request::GetAuthCode &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		clientId.CopyTo(destination.clientId);
		strcpy_s(destination.scope, NpToolkit2::Auth::Request::GetAuthCode::MAX_SIZE_SCOPE + 1, scope);
	}

	void GetIdTokenManaged::CopyTo(NpToolkit2::Auth::Request::GetIdToken &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		clientId.CopyTo(destination.clientId);
		clientSecret.CopyTo(destination.clientSecret);

		strcpy_s(destination.scope, NpToolkit2::Auth::Request::GetIdToken::MAX_SIZE_SCOPE + 1, scope);
	}
	
	int Auth::GetAuthCode(GetAuthCodeManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptAuthCodeResponse* nptResponse = new NptAuthCodeResponse();

		NpToolkit2::Auth::Request::GetAuthCode nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Auth::getAuthCode(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	int Auth::GetIdToken(GetIdTokenManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptIdTokenResponse* nptResponse = new NptIdTokenResponse();

		NpToolkit2::Auth::Request::GetIdToken nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Auth::getIdToken(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	// Marshal responses
	void Auth::MarshalAuthCode(NptAuthCodeResponse* response, MemoryBuffer& buffer, APIResult* result)
	{		
		buffer.WriteMarker(BufferIntegrityChecks::AuthCodeBegin);

		const NptAuthCode* authCode = response->get();

		buffer.WriteString(authCode->authCode.code);
		buffer.WriteUInt32((UInt32)authCode->issuerId);

		buffer.WriteMarker(BufferIntegrityChecks::AuthCodeEnd);

		SUCCESS_RESULT(result);
	}

	void Auth::MarshalIdToken(NptIdTokenResponse* response, MemoryBuffer& buffer, APIResult* result)
	{		
		buffer.WriteMarker(BufferIntegrityChecks::IdTokenBegin);

		const NptIdToken* idToken = response->get();

		buffer.WriteString(idToken->idToken.token);
		
		buffer.WriteMarker(BufferIntegrityChecks::IdTokenEnd);

		SUCCESS_RESULT(result);
	}

}
