
#include "PlatformMutex.h"
#include "../Includes/CommonTypes.h"

#include <sce_atomic.h>
#include <stdio.h>
#include <memory.h>

#define DEBUG_BREAK

#undef SCECALL
#define SCECALL(f)	{ UInt32 lResult=(f); if (SCE_OK != lResult ) {printf("[SCE] %s returned 0x%08x in %s(%d) : \n", #f, lResult, __FILE__, __LINE__ ); DEBUG_BREAK;} }

volatile int32_t PlatformMutex::m_CreateIndex = 0;
PlatformMutex::PlatformMutex ( )
{
	static const char mutexBaseName[] = "Platform Mutex ";
	static const size_t kMaxMutexName = 32;
	char mutexName[kMaxMutexName + 1];	// For Terminator

	ScePthreadMutexattr mutexAttr;
	SCECALL(scePthreadMutexattrInit(&mutexAttr));
	SCECALL(scePthreadMutexattrSettype(&mutexAttr,SCE_PTHREAD_MUTEX_RECURSIVE));
	SCECALL(scePthreadMutexattrSetprotocol(&mutexAttr, SCE_PTHREAD_PRIO_INHERIT));

	// Give each mutex a unique name to avoid SCE_KERNEL_ERROR_EWOULDBLOCK issue at https://ps4.scedev.net/technotes/view/10/1
	snprintf(mutexName, kMaxMutexName, "%s %010d",mutexBaseName, sceAtomicAdd32(&m_CreateIndex,0));
	mutexName[kMaxMutexName] = 0;
	memset(&m_Mutex, 0, sizeof(m_Mutex));
	SCECALL(scePthreadMutexInit(&m_Mutex, &mutexAttr, mutexName));
	sceAtomicIncrement32(&m_CreateIndex);

	// Ensure we clean up kernel allocations (made during scePthreadMutexattrInit) associated with our 'attr'
	// The attr does not need to persist after mutex creation
	SCECALL(scePthreadMutexattrDestroy(&mutexAttr));
}

PlatformMutex::~PlatformMutex ()
{
	// Ensure we clean up kernel allocations (made during scePthreadMutexInit) associated with our mutex
	SCECALL(scePthreadMutexDestroy(&m_Mutex));
}

void PlatformMutex::Lock()
{
	SCECALL(scePthreadMutexLock(&m_Mutex));
}

void PlatformMutex::Unlock()
{
	SCECALL(scePthreadMutexUnlock(&m_Mutex));
}

bool PlatformMutex::TryLock()
{
	return SCE_OK == scePthreadMutexTrylock(&m_Mutex);
}
