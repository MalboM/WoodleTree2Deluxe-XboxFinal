#pragma once

#include "../Includes/SonyCommonIncludes.h"

#include "PlatformMutex.h"
#include <sce_atomic.h>

namespace NPT
{
	int AtomicExchange(int volatile* i, int value);
	bool AtomicCompareExchange (int volatile* i, int newValue, int expectedValue);

	class Mutex : PlatformMutex
	{
	public:

		void Lock()
		{
			PlatformMutex::Lock();
		}

		void UnLock()
		{
			PlatformMutex::Unlock();
		}
	};

	class AsyncCallbackAutoLock
	{
		static Mutex lock;
	public:

		AsyncCallbackAutoLock()
		{
			//lock.Lock();
		}

		~AsyncCallbackAutoLock()
		{
			//lock.UnLock();
		}
	};

	class ResponseMapAutoLock
	{
		static Mutex lock;
	public:

		ResponseMapAutoLock()
		{
			lock.Lock();
		}

		~ResponseMapAutoLock()
		{
			lock.UnLock();
		}
	};
}