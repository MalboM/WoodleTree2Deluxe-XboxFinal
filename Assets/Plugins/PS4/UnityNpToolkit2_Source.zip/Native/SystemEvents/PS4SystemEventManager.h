#pragma once

#if defined(GLOBAL_EVENT_QUEUE)
namespace UnityPlugin
{
	class PS4SystemEventManager
	{
	public:
		PS4SystemEventManager() : m_EventQueue(NULL) {}
		~PS4SystemEventManager() {}

		void Initialize(UnityEventQueue::IEventQueue* eventQueue);
		void Shutdown();

		void HandleEvent(PS4OnResume& data);
		void HandleEvent(PS4OnGameLiveStreamingStatusUpdate& data);
		void HandleEvent(PS4OnSessionInvitation& data);
		void HandleEvent(PS4OnEntitlementUpdate& data);
		void HandleEvent(PS4OnGameCustomData& data);
		void HandleEvent(PS4OnDisplaySafeAreaUpdate& data);
		void HandleEvent(PS4OnUrlOpen& data);
		void HandleEvent(PS4OnLaunchApp& data);
		void HandleEvent(PS4OnLaunchLink& data);
		void HandleEvent(PS4OnAddcontentInstall& data);
		void HandleEvent(PS4OnResetVrPosition& data);
		void HandleEvent(PS4OnJoinEvent& data);
		void HandleEvent(PS4OnPlaygoLocusUpdate& data);
		void HandleEvent(PS4OnOpenShareMenu& data);
		void HandleEvent(PS4OnPlayTogetherHost& data);

	private:
		UnityEventQueue::IEventQueue* m_EventQueue;
	};
}
#endif
